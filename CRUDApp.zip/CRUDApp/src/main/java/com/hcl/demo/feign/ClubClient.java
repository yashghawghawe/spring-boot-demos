package com.hcl.demo.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.hcl.demo.dto.ClubDTO;
import com.hcl.demo.dto.ClubRequestDTO;

//@FeignClient(value = "club-service", url = "http://CLUB-SERVICE/club/clubs")
@FeignClient(name="http://CLUB-SERVICE/club/clubs")
public interface ClubClient {
	
	@GetMapping("/port")
	public String getPortNumber();

	@GetMapping("/{playerId}")
	public List<ClubDTO> getClubsByPlayerId(@PathVariable("playerId") int playerId);

	@GetMapping
	public List<ClubDTO> getClubsByPlayerIdAsRequestParam(@RequestParam("playerId") int playerId);

	@PostMapping("/saveClub")
	public List<ClubDTO> postClubByPlayerId(@RequestBody ClubRequestDTO clubRequestDTO);
}
