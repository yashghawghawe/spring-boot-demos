package com.hcl.demo.controller;

import java.util.List;

import javax.jms.Queue;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.demo.dto.ClubDTO;
import com.hcl.demo.dto.ClubRequestDTO;
import com.hcl.demo.dto.PlayerDTO;
import com.hcl.demo.dto.PlayerResponse;
import com.hcl.demo.entity.Player;
import com.hcl.demo.feign.ClubClient;
import com.hcl.demo.service.PlayerService;

@RestController
@RequestMapping("/players")
public class PlayerController {

	@Autowired
	private ClubClient clubClient;

	@Autowired
	private PlayerService service;

	@Autowired
    private Queue queue;

    @Autowired
    private JmsTemplate jmsTemplate;
	
	@PostMapping
	public Player savePlayer(@RequestBody Player player) {
		return service.savePlayer(player);
	}

	@GetMapping("/port")
	public String getPortNumber() {
		String port = clubClient.getPortNumber();
		return port;
	}

	@GetMapping
	public List<Player> getAll(@RequestParam int pageNumber, @RequestParam int pageSize) {
		return service.getAll(pageNumber, pageSize);
	}

	@GetMapping("/{playerid}/clubs")
	public PlayerResponse getPlayer(@PathVariable("playerid") long playerid) {
		jmsTemplate.convertAndSend(queue, playerid);
		PlayerResponse playerResponse = new PlayerResponse();
		Player player = service.getPlayer(playerid);
		PlayerDTO playerDTO = new PlayerDTO();
		BeanUtils.copyProperties(player, playerDTO);
		playerResponse.setPlayer(playerDTO);
		List<ClubDTO> clubs = clubClient.getClubsByPlayerId((int) playerid);
		playerResponse.setClubs(clubs);
		return playerResponse;
	}

	@GetMapping("/getbyparam/clubs")
	public PlayerResponse getPlayerById(@RequestParam int playerId) {
		PlayerResponse playerResponse = new PlayerResponse();
		Player player = service.getPlayer(playerId);
		PlayerDTO playerDTO = new PlayerDTO();
		BeanUtils.copyProperties(player, playerDTO);
		playerResponse.setPlayer(playerDTO);
		List<ClubDTO> clubs = clubClient.getClubsByPlayerIdAsRequestParam(playerId);
		playerResponse.setClubs(clubs);
		return playerResponse;
	}

	@PostMapping("/clubs")
	public PlayerResponse postClubByPlayerId(@RequestBody ClubRequestDTO clubRequestDTO) {
		PlayerResponse playerResponse = getPlayerResponse(clubRequestDTO.getPlayerId());
		playerResponse.setClubs(clubClient.postClubByPlayerId(clubRequestDTO));
		return playerResponse;
	}

	private PlayerResponse getPlayerResponse(long playerid) {
		PlayerResponse playerResponse = new PlayerResponse();
		Player player = service.getPlayer(playerid);
		PlayerDTO playerDTO = new PlayerDTO();
		BeanUtils.copyProperties(player, playerDTO);
		playerResponse.setPlayer(playerDTO);
		return playerResponse;
	}

	@DeleteMapping("/{playerid}")
	public void deletePlayer(@PathVariable("playerid") long playerid) {
		service.deletePlayer(playerid);
	}

	@GetMapping("/byName")
	public List<Player> findByAge(@RequestParam int age) {
		return service.findByAgeLessThan(age);
	}

	@GetMapping("/details")
	public List<PlayerDTO> getDetails(@RequestParam String firstName) {
		List<PlayerDTO> dtos = service.getDetails(firstName);
		return dtos;
	}
}
