package com.hcl.demo.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.hcl.demo.dto.PlayerDTO;
import com.hcl.demo.entity.Player;
import com.hcl.demo.feign.ClubClient;
import com.hcl.demo.repository.PlayerRepository;
import com.hcl.demo.service.PlayerService;

@Service
public class PlayerServiceImpl implements PlayerService {

	@Autowired
	private PlayerRepository repository;
	
	@Autowired
	private ClubClient clubClient;

	@Override
	public Player savePlayer(Player player) {
		return repository.save(player);
	}

	@Override
	public List<Player> getAll(int pageNumber, int PageSize) {
		Pageable pageable = PageRequest.of(pageNumber, PageSize, Sort.by(Direction.ASC, "age"));
		return repository.findAll(pageable).getContent();
	}

	@Override
	public Player getPlayer(long playerid) {
		Optional<Player> player = repository.findById(playerid);
		if (player.isPresent()) {
			return player.get();
		}
		return null;
	}

	@Override
	public Player updatePlayer(long playerid, Player player) {
		Player dbPlayer = getPlayer(playerid);
		dbPlayer.setFirstName(player.getFirstName());
		dbPlayer.setLastName(player.getLastName());
		dbPlayer.setPosition(player.getPosition());
		dbPlayer.setAge(player.getAge());
		return repository.save(dbPlayer);
	}

	@Override
	public void deletePlayer(long playerid) {
		repository.deleteById(playerid);

	}

	@Override
	public List<Player> getByFirstName(String name) {
		return repository.findByLastNameOrderByAgeAsc(name);
	}

	@Override
	public List<Player> getByFirstNameAndLastName(String firstName, String lastName) {
		return repository.findByFirstNameAndLastName(firstName, lastName);
	}

	@Override
	public List<Player> getByLastNameContains(String lastName) {
		return repository.findByLastNameContainsOrderByAgeAsc(lastName);
	}

	@Override
	public List<Player> getAll() {
		return repository.findAll();
	}

	@Override
	public List<Player> findByAgeLessThan(int age) {
		Pageable pageable = PageRequest.of(0, 5, Sort.by(Direction.ASC, "age"));
		return repository.findByAgeLessThan(age, pageable);
	}

	@Override
	public List<Player> findByAgeGreaterThan(int age) {
		return repository.findByAgeGreaterThan(age);
	}

	@Override
	public List<Player> findByAgeGreaterThan(int age, Pageable pageable) {
		return repository.findByAgeGreaterThan(age, pageable);
	}

	// @Override   
	// public List<Player> findByAgeNull(int age) {
	// return repository.findByAgeNull(age);
	// }

	@Override
	public List<PlayerDTO> getDetails(String firstName) {
		return repository.getDetails(firstName);
	}

	@Override
	public String getPortNumber() {
		return clubClient.getPortNumber();
	}

}
