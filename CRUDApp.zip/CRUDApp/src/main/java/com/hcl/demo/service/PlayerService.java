package com.hcl.demo.service;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.hcl.demo.dto.PlayerDTO;
import com.hcl.demo.entity.Player;

public interface PlayerService {

	Player savePlayer(Player player);

	List<Player> getAll();

	Player getPlayer(long playerid);

	Player updatePlayer(long playerid, Player player);

	void deletePlayer(long playerid);

	List<Player> getByFirstName(String name);

	List<Player> getByFirstNameAndLastName(String firstName, String lastName);

	List<Player> getByLastNameContains(String lastName);

	List<Player> getAll(int pageNumber, int PageSize);

	List<Player> findByAgeLessThan(int age);

	List<Player> findByAgeGreaterThan(int age, Pageable pageable);

	List<Player> findByAgeGreaterThan(int age);
	//
	// List<Player> findByAgeNull(int age);

	List<PlayerDTO> getDetails(String firstName);

	String getPortNumber();

}
