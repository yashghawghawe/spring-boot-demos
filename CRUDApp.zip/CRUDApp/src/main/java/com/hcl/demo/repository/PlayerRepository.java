package com.hcl.demo.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcl.demo.dto.PlayerDTO;
import com.hcl.demo.entity.Player;

@Repository
public interface PlayerRepository extends JpaRepository<Player, Long> {

	public List<Player> findByFirstName(String name);

	public List<Player> findByLastName(String name);

	public List<Player> findByLastNameOrderByAgeAsc(String name);

	public List<Player> findByFirstNameAndLastName(String firstName, String lastName);

	public List<Player> findByLastNameContainsOrderByAgeAsc(String lastName);

	public List<Player> findByAgeLessThan(int age, Pageable pageable);

	public List<Player> findByAgeNull();

	public List<Player> findByAgeGreaterThan(int age);

	public List<Player> findByAgeGreaterThan(int age, Pageable pageable);

	// public List<Player> findByAgeNull(int age);

	@Query("select new com.hcl.demo.dto.PlayerDTO(firstName,position,age) from Player where firstName=:firstName")
	public List<PlayerDTO> getDetails(@Param(value = "firstName") String firstName);

}
