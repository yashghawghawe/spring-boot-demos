package com.yash.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
public class Customer {

		@Id
		@Column(name="txn_id", unique=true, nullable=false)
		@GeneratedValue(generator="gen")
		@GenericGenerator(name="gen", strategy="foreign", parameters={@Parameter(name="property", value="transaction")})
		private long id;
		
		@Column(name="cust_name")
		private String name;
		
		@Column(name="cust_email")
		private String email;
		
		@Column(name="cust_address")
		private String address;
		
		@OneToOne
		@PrimaryKeyJoinColumn
		private Transaction transaction;

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public Transaction getTransaction() {
			return transaction;
		}

		public void setTransaction(Transaction transaction) {
			this.transaction = transaction;
		}

}
