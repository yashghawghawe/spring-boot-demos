package com.main;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.yash.model.Adddress;
import com.yash.model.Cart;
import com.yash.model.Items;
import com.yash.model.Student;
import com.yash.util.HibernateUtil;

public class Application {

	public static void main(String[] args) {
		SessionFactory factory = null;
		Session session = null;
		org.hibernate.Transaction transaction = null;

		try {
			factory = HibernateUtil.getSessionFactory();
			session = factory.openSession();
			System.out.println("Session created");

			transaction = session.beginTransaction();

			Cart cart = new Cart();
			cart.setDate(new Date());

			Items items1 = new Items();
			items1.setItems(2);
			items1.setTotal(4000);
			items1.setCart(cart);

			Items items2 = new Items();
			items2.setItems(3);
			items2.setTotal(6000);
			items2.setCart(cart);

			List<Items> items = Arrays.asList(items1, items2);
			cart.setItems(items);

			// session.save(cart);
			// session.save(items1);
			// session.save(items2);

			// Criteria criteria = session.createCriteria(Cart.class);
			// List<Cart> list = criteria.list();
			//
			// for (Cart items3 : list) {
			// System.out.println(items3);
			// }
			// Query query = session.createQuery("select cart_id,date from
			// Cart");
			// List<Object[]> resultantCart = (List<Object[]>) query.list();
			//
			// for (Object[] carts : resultantCart) {
			// System.out.println(carts[0] +" : "+ carts[1]);
			// }

			// Query query = session.createQuery("from Items i where
			// i.total>2000");
			// List<Items> items3 = query.list();
			//
			// for (Items item : items3) {
			// System.out.println(item);
			// }

			// List<Items> items3 = cart2.getItems();
			// for (Items items4 : items3) {
			// System.out.println(items4);
			// }

			// Cart cart2 = session.load(Cart.class, 65);
			// System.out.println(cart2);
			Student student = new Student();
			student.setFname("Yash");
			student.setLname("Ghawghawe");
			student.setRollNo(110);
			student.setAddress(new Adddress("Plot no.6,Ratan Nagar","Nagpur","Maharashtra","440009"));
			
			session.save(student);

			transaction.commit();
			System.out.println("closing Session1");
			session.close();

		} catch (Exception e) {
			System.out.println("Exception Occured : \n " + e.getMessage());
		}

	}

}
