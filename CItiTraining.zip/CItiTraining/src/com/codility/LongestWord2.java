package com.codility;

public class LongestWord2 {
    
    public static int solution(String s){
        String arr[] = s.split("[.!?]");
        int longestWord = 0;
        for (int i = 0; i < arr.length; i++) {
            if (longestWord < arr[i].trim().length()) {
                longestWord = arr[i].trim().length();
            }
        }
        return longestWord;
    }
    public static void main(String[] args) {
        String ss = " my name. is! yashraj?";
        int result = solution(ss);
        System.out.println(result);
    }
}
