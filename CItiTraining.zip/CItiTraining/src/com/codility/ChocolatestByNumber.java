package com.codility;

import java.util.Scanner;

public class ChocolatestByNumber {
    
    public static int solution(int n,int m){
        int value = 0,start = 0;
        int result = 1;
        while ((start + m) % n != 0) {
            value = (start + m) % n;
            start = value;
            result++;
        }
        return result;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choccolates = sc.nextInt();
        int omit = sc.nextInt();
        int result = solution(choccolates, omit);
        System.out.println(result);
        sc.close();
    }
}
