package com.codility;

import java.util.Scanner;

public class TwoNumbers {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int result = solution(a, b);
        System.out.println(result);
        sc.close();
    }

    private static int solution(int a, int b) {
        String A = a + "";
        String B = b + "";
        if (B.contains(A)) {
            return B.indexOf(A);
        }
        return -1;
    }

}
