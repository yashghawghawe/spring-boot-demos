package com.codility;

import java.util.Arrays;
import java.util.Scanner;

public class LongestWord {

    public static int solution(String s) {
        String ss = "this.is!java?";
        String arr[] = ss.split("[.!?]");
        int longestWord = 0;
        for (int i = 0; i < arr.length; i++) {
            if (longestWord < arr[i].trim().length()) {
                longestWord = arr[i].trim().length();
            }
        }
        //        int longestWord = 0;
        //        for (String word : str) {
        //            if (longestWord < word.length()) {
        //                longestWord = word.length();
        //            }
        //        }
        //return longestWord;

        return Arrays.stream(s.split("[.!?]")).map(String::trim)
                .filter(str -> !str.isEmpty()).mapToInt(s1 -> s1.split("\\s+").length)
                .max().orElse(0);

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        int result = solution(s);
        System.out.println(result);
        sc.close();
    }
}
