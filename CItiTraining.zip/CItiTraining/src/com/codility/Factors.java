package com.codility;

import java.util.Scanner;

public class Factors {
    public static int solution(int N){
        int count = 0;
        
        return 0;
        
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        int result = solution(number);
        System.out.println(result);
        sc.close();
    } 
}
