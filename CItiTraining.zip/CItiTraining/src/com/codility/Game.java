package com.codility;

import java.util.LinkedList;
import java.util.Scanner;

public class Game {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        String result = solution(arr, s);
        System.out.println(result);
    }

    private static String solution(int[] arr, String s) {
        String result = "";
        LinkedList<Character> list = new LinkedList<>();
        for (int i = 0; i < arr.length; i++) {
            list.add(s.charAt(i));
        }
        result+=list.poll();
        result+=list.pollLast();
        result+=list.poll();
        result+=list.pollLast();
        return result;
    }

}
