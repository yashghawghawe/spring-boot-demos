package com.codility;

import java.util.Scanner;

public class TieRopes {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int k = sc.nextInt();
        int result = solution(arr, k);
        System.out.println(result);
        sc.close();
    }

    private static int solution(int[] arr, int k) {
        int length = 0;
        int result = 0;
        for (int rope : arr) {
            length = length + rope;
            if (length >= k) {
                result++;
                length = 0;
            }
        }
        return result;
    }
}
