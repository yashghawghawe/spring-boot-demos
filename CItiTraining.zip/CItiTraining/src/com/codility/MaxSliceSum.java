package com.codility;

import java.util.Scanner;

public class MaxSliceSum {
    
    public static int solution(int a[]){
        int max = a[0];
        int max_so_far = a[0];
        for (int i = 1; i < a.length; i++) {
            max_so_far = Math.max(a[i],a[i] + max_so_far);
            if (max_so_far > max) {
                max = max_so_far;
            }
        }
        return max;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int result = solution(arr);
        System.out.println(result);
        sc.close();
    }

}
