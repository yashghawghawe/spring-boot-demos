package com.codility;

import java.util.Scanner;

public class OneBit {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int A = sc.nextInt();
        int B = sc.nextInt();
        int result = solution(A, B);
        System.out.println(result);
    }

    private static int solution(int a, int b) {
        int result = a * b;
        int bitcount = Integer.bitCount(result);
        return bitcount;
    }

}
