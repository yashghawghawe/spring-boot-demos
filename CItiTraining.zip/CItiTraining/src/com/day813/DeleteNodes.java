package com.day813;

class Node {
    int data;
    Node next;

    void displayData() {
        System.out.println("[ " + data + " ]");
    }
}

class SingleLinkedList {
    private Node head;

    public void insertFirst(int data) {
        Node newNode = new Node();
        newNode.data = data;
        newNode.next = head;
        head = newNode;
    }

    public void insertAfter(int data) {
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        Node newNode = new Node();
        newNode.data = data;
        current.next = newNode;
    }

    public void printList() {
        System.out.println("Printing List Elements");
        Node firstNode = head; //head
        while (firstNode != null) {
            firstNode.displayData();
            firstNode = firstNode.next;
        }
    }

    public void deleteNode(Node deletenode) {
        Node temp = head;
        while (temp.next != null && temp.data != deletenode.data) {
            temp = temp.next;
        }
        if (temp.next != null) {
            if (temp.data >= deletenode.data) {
                while(temp.next != null){
                temp.next = temp.next.next;
                }
            }
        }
    }
}

public class DeleteNodes {
    public static void main(String[] args) {
        SingleLinkedList linkedList = new SingleLinkedList();
        linkedList.insertFirst(10);
        linkedList.printList();
        linkedList.insertAfter(11);
        linkedList.printList();
        linkedList.insertAfter(12);
        linkedList.printList();
        linkedList.insertAfter(13);
        linkedList.printList();
        Node node = new Node();
        node.data = 11;
        linkedList.deleteNode(node);
        linkedList.printList();
    }
}
