package com.test6;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Warehouse {

    public static int restock(List<Integer> itemCount, int target) {
        int max = 0;
        for (int i = 0; i < itemCount.size(); i++) {
            max = itemCount.get(i) + max;
            if (max >= target) {
                return max-target;
            }
        }
        return target-max;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Integer> arr = new ArrayList<Integer>();
        int size = sc.nextInt();
        for (int i = 0; i < size; i++) {
            arr.add(sc.nextInt());
        }
        int target = sc.nextInt();
        int result = restock(arr, target);
        System.out.println(result);
        sc.close();
    }
}
