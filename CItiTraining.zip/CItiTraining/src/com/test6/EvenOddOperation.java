package com.test6;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EvenOddOperation {
    public static long getMaximumScore(List<Integer> integerArray) {
        long score = 0;
        long arraysum =0;
        List<Integer> list = new ArrayList<>(integerArray);
        for (int i = 0; i < integerArray.size(); i++) {
            arraysum = list.get(i) + arraysum;
        }
        for (int i = 1; i <= integerArray.size(); i++) {
            if (i % 2 != 0) {
                score = score + arraysum;
                arraysum = arraysum - list.get(list.size()-1);
                list.remove(list.size()-1);
            }else if (i%2 == 0) {
                score = score - arraysum;  
                arraysum = arraysum - list.get(list.size()-1);
                list.remove(i-1);
            }
        }
        return score;
        }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Integer> arr = new ArrayList<Integer>();
        int size = sc.nextInt();
        for (int i = 0; i < size; i++) {
            arr.add(sc.nextInt());
        }
        long result = getMaximumScore(arr);
        System.out.println(result);
        sc.close();
    }
}
