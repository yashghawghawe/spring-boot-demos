package com.test6;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class DamDesign {

    public static int maxHeight(int[] stickPositions, int[] stickHeights) {
        int n = stickPositions.length;
        int max = 0;
        for (int i = 0; i < n - 1; i++) {
            if (stickPositions[i] < stickPositions[i + 1] - 1) {
                int gapLen = stickPositions[i + 1] - stickPositions[i] - 1;
                    int localMax = Math.min(stickHeights[i + 1], stickHeights[i]) + gapLen;
                max = Math.max(max, localMax);
            }
        }
        return max;
    }

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] stickPositions = new int[n];
        for (int i = 0; i < n; i++) {
            stickPositions[i] = scanner.nextInt();
        }
        n = scanner.nextInt();
        int[] stickHeights = new int[n];
        for (int i = 0; i < n; i++) {
            stickHeights[i] = scanner.nextInt();
        }
        System.out.println(maxHeight(stickPositions, stickHeights));
        scanner.close();
    }
}
