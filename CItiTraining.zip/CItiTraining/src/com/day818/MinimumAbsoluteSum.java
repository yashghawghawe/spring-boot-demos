package com.day818;

import java.util.Arrays;
import java.util.Scanner;

public class MinimumAbsoluteSum {

    public static int solution(int a[]) {
        Arrays.sort(a);
        int start = 0;
        int end = a.length - 1;
        int minAbsSum = Math.abs(a[start] + a[end]);
        while (start < end) {
            int newSum = 0;
            if (Math.abs(a[start + 1] + a[end]) < Math.abs(a[start] + a[end - 1])) {
                newSum = Math.abs(a[start +1] + a[end]);
                start++;
            }else{
                newSum = Math.abs(a[start] + a[end -1]);
                end--;
            }
            minAbsSum = Math.min(minAbsSum, newSum);
        }
        return minAbsSum;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int result = solution(arr);
        System.out.println(result);
        sc.close();
    }
}
