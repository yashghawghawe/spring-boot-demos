package com.day818;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class OneBitRepresentation {

    public static List<Integer> getOneBits(int num) {
        String binary = Integer.toBinaryString(num);
        int bitCount = Integer.bitCount(num);
        LinkedHashMap<Integer, Character> map = new LinkedHashMap<Integer, Character>();
        int j = 0;
        for (int i = 0; i < binary.length(); i++) {
            j++;
            map.put(j, binary.charAt(i));
        }
        Iterator<Entry<Integer, Character>> it = map.entrySet().iterator();
        List<Integer> list = new ArrayList<Integer>();
        int count = 0;
        while (it.hasNext()) {
            Map.Entry<Integer, Character> e = (Map.Entry<Integer, Character>) it.next();
            if (e.getValue() == '1') {
                count++;
                if (count >= bitCount) {
                    list.add(0, count);
                }
                list.add(e.getKey());
            }
        }
        return list;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        List<Integer> result = getOneBits(number);
        for (int i : result) {
            System.out.println(i);
        }
        sc.close();
    }
}
