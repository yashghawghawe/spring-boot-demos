package com.Day1;

import java.util.Scanner;

public class Password {
    Password(){
        
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String username = sc.nextLine();

        char firstLetter = username.charAt(0);
        char lastLetter = username.charAt(username.length() - 1);
        int lastASCII = lastLetter;
        int firstASCII = firstLetter;
        String password = " " + firstLetter + lastLetter + lastASCII + firstASCII;
        System.out.println(password);
        sc.close();
        
    }

}
