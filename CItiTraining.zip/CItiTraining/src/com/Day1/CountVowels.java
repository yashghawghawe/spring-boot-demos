package com.Day1;

public class CountVowels {

    public static void main(String[] args) {
        String sentence = "This world is awesome!";
        sentence = sentence.toLowerCase();
        int vowels = 0;
        
        for (int i = 0; i < sentence.length(); i++) {
            char ch = sentence.charAt(i);
            if (ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u') {
                vowels++;
            }
        }
        System.out.println(vowels);
    }

}
