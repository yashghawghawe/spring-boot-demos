package com.Day1;

public class CommandLine {

    public static void main(String[] args) {
        int f = 1;
        int n = Integer.parseInt(args[0]);
        for (int i = 1; i <= n; i++) {
            f = f * i;
        }
        System.out.println("factorial of given number is :" + f);
    }

}
