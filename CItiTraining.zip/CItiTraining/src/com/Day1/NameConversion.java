package com.Day1;

public class NameConversion {
    
    public static void main(String[] args) {
        String name = "YashRaj";
        String firstLetter = name.substring(0, 1);
        String lowercase = firstLetter.toLowerCase();
        System.out.println(lowercase);
        String rest = name.substring(1, 7);
        String uppercase = rest.toUpperCase();
        System.out.println(uppercase);
        String converted = lowercase + uppercase;
        System.out.println(converted);
        
        float f = 0.5f;
        if(f == (float)0.5) {
        System.out.println("Hi");
        }else {
        System.out.println("Hello");
        }
    }

}
