package com.Day1;

import java.util.Scanner;

public class NumberReversed2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        solution(number);
        sc.close();
    }

    public static void solution(int number) {
        int value  = number  % 10;
        while(number != 0){
            if (value == 0) {
                value = 1;
            }
            else{
                if (value != 0) {
                    System.err.println(number % 10);
                }
            }
            number = number /10;
        }
    }

}
