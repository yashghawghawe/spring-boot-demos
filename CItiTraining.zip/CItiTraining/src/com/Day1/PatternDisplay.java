package com.Day1;

public class PatternDisplay {

    public static void main(String[] args) {
        int n = 4;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print("X");
            }
            System.out.println();
        }
        //for 101 pattern
        for (int i = 1; i <= 4; i++) {
            for (int j = 1; j <= i; j++) {
                if (j % 2 == 1) {
                    System.out.print("1");
                } else {
                    System.out.print("0");
                }
            }
            System.out.println();
        }

    }

}
