package com.Day1;

public class ArmstrongNumber {

    public static void main(String[] args) {

        int num = 153;
        int originalNumber = num;
        int remainder, result = 0;

        while (originalNumber != 0) {
            remainder = originalNumber % 10;
            result = (int) (result + Math.pow(remainder, 3));
            originalNumber /= 10;
        }
        if (result == num) {
            System.out.println(num + " is an armstrong Number");
        } else {
            System.out.println(num + " It is not an armstrong number");
        }

    }

}
