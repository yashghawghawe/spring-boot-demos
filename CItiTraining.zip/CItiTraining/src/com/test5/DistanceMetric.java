package com.test5;

import java.util.Scanner;

public class DistanceMetric {
    public static int[] solution(int[] list) {
        int result[] = new int[list.length];
        int sum = 0;
        for (int i = 0; i < result.length; i++) {
            for (int j = 0; j < result.length; j++) {
                if (i!=j) {
                    if (list[i] == list[j]) {
                        sum = sum + Math.abs(i-j);
                    }
                }
            }
            result[i] = sum;
            sum = 0;
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int[] result = solution(arr);
        for (int i : result) {
            System.out.println(i);
        }
        sc.close();
    }
}
