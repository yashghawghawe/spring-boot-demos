package com.test5;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class PowerCompany {

    public static int reduceCapacity(List<Integer> model) {
        int ceiling = model.size() / 2;
        int toatlGenerators = 0;
        int sum = 0;
        LinkedHashMap<Integer, Integer> models = new LinkedHashMap<>();
        for (Integer m : model) {
            if (models.containsKey(m)) {
                models.put(m, models.get(m) + 1);
            } else {
                models.put(m, 1);
            }
        }
        for (Map.Entry<Integer, Integer> entry : models.entrySet()) {
            if (sum <= ceiling) {
                if (entry.getValue() >= 2) {
                    toatlGenerators++;
                    sum += entry.getValue();
                }
            }
        }
        return toatlGenerators;

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        List<Integer> model = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            model.add(sc.nextInt());
        }
        int result = reduceCapacity(model);
        System.out.println(result);
        sc.close();
    }

}
