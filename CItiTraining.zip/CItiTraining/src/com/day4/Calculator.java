package com.day4;

import java.util.Scanner;

class Calculator implements AdvancedArithmetic {

    @Override
    public int divisor_sum(int n) {
        int result =0 ;
        System.out.println("I implemented : AdvancedArithmetic ");
        for (int i = 1; i < 10; i++) {
            if (n % i == 0) {
                result = result + i;
            }
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        Calculator cal = new Calculator();
        int result = cal.divisor_sum(number);
        System.out.println(result);
        sc.close();
    }
}
