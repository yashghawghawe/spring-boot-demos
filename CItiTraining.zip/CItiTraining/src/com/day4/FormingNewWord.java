package com.day4;

import java.util.Scanner;

public class FormingNewWord {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String word = sc.next();
        int n = sc.nextInt();
        String result = formNewWord(word, n);
        System.out.println(result);

    }

    private static String formNewWord(String word, int n) {
        int length = word.length();
        String beforeN = word.substring(0, n);
        char c = beforeN.charAt(0);
        beforeN = beforeN.replace(c, Character.toUpperCase(c));
        String afterN = word.substring(length - n, length);
        return beforeN + afterN;
    }
}
