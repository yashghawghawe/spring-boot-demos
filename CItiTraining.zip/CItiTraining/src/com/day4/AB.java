package com.day4;

public class AB {
    int a = 100;

    public void display() {
        System.out.printf("a in A = %d\n", a);
    }

}
