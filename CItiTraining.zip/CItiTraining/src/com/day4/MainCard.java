package com.day4;

import java.util.Scanner;

public class MainCard {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Select the Card ");
        System.out.println("1. Payback Card");
        System.out.println("2. Membership Card");
        int n = sc.nextInt();
        System.out.println("Enter The CardDetails : ");
        String details = sc.next();
        String[] word = details.split("\\|");
        switch (n) {
            case 1:
                System.out.println("Enter points in card : ");
                int pointsEarned = sc.nextInt();
                System.out.println("Enter Amount : ");
                double totalAmount = sc.nextDouble();
                PaybackCard paybackCard = new PaybackCard(word[0], word[1], word[2], pointsEarned,
                        totalAmount);
                System.out.println(word[0] + "'s" + " Card Details");
                System.out.println("Card Number " + word[1]);
                System.out.println("Points Earned : " + paybackCard.getPointsEarned());
                System.out.println("Total Amount : " + paybackCard.getTotalAmount());
                break;
            case 2:
                System.out.println("Enter rating : ");
                int rating = sc.nextInt();
                MembershipCard membershipCard = new MembershipCard(word[0], word[1], word[2], rating);
                System.out.println(word[0] + "s" + " Card Details");
                System.out.println("Card Rating : " + membershipCard.getRating());
            default:
                System.out.println("Invalid Choice");
                break;
        }
        sc.close();
    }

}
