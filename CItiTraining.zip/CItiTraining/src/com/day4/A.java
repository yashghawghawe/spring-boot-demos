package com.day4;

public class A {
    public int a = 100;
    public void setA( int value) {
        a = value;
}
    public int getA() {
        return a;
    }
} 

