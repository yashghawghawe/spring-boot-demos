package com.day4;

public class OOPExercises {
    public static void main(String[] args) {
        A objA = new A();
        System.out.println("in main(): ");
        System.out.println("objA.a = "+objA.a);
        objA.a = 222;
    }
}

