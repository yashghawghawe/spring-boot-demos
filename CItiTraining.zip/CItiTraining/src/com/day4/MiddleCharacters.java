package com.day4;

import java.util.Scanner;

public class MiddleCharacters {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter  a even length word : ");
        String word = sc.next();
        String result = getMiddleChars(word);
        System.out.println(result);
        sc.close();
    }

    private static String getMiddleChars(String word) {
        StringBuffer sb = new StringBuffer();
        if (word.length() % 2 == 0) {
            sb.append(word.substring(word.length() / 2 - 1, (word.length() / 2) + 1));
        }
        return sb.toString();
    }
}
