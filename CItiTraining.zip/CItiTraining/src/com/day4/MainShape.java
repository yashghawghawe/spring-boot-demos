package com.day4;

import java.util.Scanner;

public class MainShape {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String shape = sc.next();

        if (shape.equalsIgnoreCase("circle")) {
            System.out.println("Enter Radius : ");
            int r = sc.nextInt();
            Circle circle = new Circle(shape, r);
            float result = circle.calaculateArea();
            System.out.printf("%.2f", result);
        } else if (shape.equalsIgnoreCase("square")) {
            System.out.println("Enter Side : ");
            int s = sc.nextInt();
            Square square = new Square(shape, s);
            float result = square.calaculateArea();
            System.out.printf("%.2f", result);
        } else if(shape.equalsIgnoreCase("square")) {
            System.out.println("Enter Length and breadth : ");
            int l = sc.nextInt();
            int b = sc.nextInt();
            Rectangle rectangle = new Rectangle(shape, l, b);
            float result = rectangle.calaculateArea();
            System.out.printf("%.2f", result);
        }else{
            System.out.println("Wrong Input");
        }
        sc.close();
    }
}
