package com.day4;

import java.util.Scanner;

public class NumberValidation {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number in format XXX-XXX-XXXX :");
        String number =sc.next();
        
        if (number.matches("\\d{3}[-]\\d{3}[-]\\d{4}")) {
            System.out.println("Valid number format");
        }else
            System.out.println("Invalid number format");
        sc.close();
    }
}
