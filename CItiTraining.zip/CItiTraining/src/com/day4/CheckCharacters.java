package com.day4;

import java.util.Scanner;

public class CheckCharacters {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String word = sc.nextLine();
        int result = checkCharacters(word);
        System.out.println(result);
        sc.close();
    }

    private static int checkCharacters(String word) {
        for (int i = 0; i < word.length() - 1; i++) {
            if (word.charAt(i) == word.charAt(word.length() - 1)) {
                return 1;
            }
        }
        return 0;
    }
}
