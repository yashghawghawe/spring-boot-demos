package com.day814;

class Kadane {
    //Maximum Slice Problem
    public static void main(String[] args) {
        int[] a = { 3, 2, -6, 4, 0 };
        System.out.println("Maximum contiguous sum is " +
                maxSubArraySum(a));
    }

    static int maxSubArraySum(int a[]) {
        int max = a[0];
        int max_so_far = a[0];
        for (int i = 0; i < a.length; i++) {
            max_so_far = Math.max(a[i], a[i] + max_so_far);
            if (max_so_far > max) {
                max = max_so_far;
            }
        }
        return max;
    }
}
