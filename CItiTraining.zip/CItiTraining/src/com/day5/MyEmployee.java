package com.day5;

/**
 * @author yash.ghawghawe
 *
 */
public class MyEmployee implements PrcoessInfo {

    @Override
    public void registerEmp(Employee emp) {
        System.out.println("Employee Details");
        System.out.println("Employee SAPID : "+emp.getEmpid()+"\nEmployee Name : "+emp.getEmpName()
        +"\nDesignation : " +emp.getJob());
    }

    @Override
    public void viewEmp(int empId) {
        System.out.println("Employee ID is : "+empId);
    }

}
