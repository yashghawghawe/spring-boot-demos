package com.day5;

/**
 * @author yash.ghawghawe
 *
 */
public interface IBankMaster {
   
    abstract void deposit(double amount);
    abstract void withdraw(double amount) throws InsufficientBalException;

}