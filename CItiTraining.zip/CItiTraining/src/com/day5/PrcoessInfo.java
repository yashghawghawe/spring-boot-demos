package com.day5;

/**
 * @author yash.ghawghawe
 *
 */
public interface PrcoessInfo {
   
    abstract void registerEmp(Employee emp);
   
    abstract  void viewEmp(int empId);

}
