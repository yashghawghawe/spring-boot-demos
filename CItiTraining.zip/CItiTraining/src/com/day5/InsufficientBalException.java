package com.day5;

/**
 * @author yash.ghawghawe
 *
 */
public class InsufficientBalException extends Exception {

    private static final long serialVersionUID = 1L;
    String str;
    InsufficientBalException(String str) {
       this.str=str;
    }
    
    public String toString(){
        return str;
    }
}
