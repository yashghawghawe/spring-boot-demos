package com.day5;

/**
 * @author yash.ghawghawe
 *
 */
public class MainEmployee {

    public static void main(String[] args) {
        Employee employee = new Employee();
        employee.setEmpid(51862644);
        employee.setEmpName("Yash");
        employee.setJob("Developer");
        MyEmployee myEmployee = new MyEmployee();
        myEmployee.registerEmp(employee);
        myEmployee.viewEmp(51862644);

    }
}
