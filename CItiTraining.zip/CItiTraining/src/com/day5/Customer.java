package com.day5;

import java.util.Scanner;

/**
 * @author yash.ghawghawe
 *
 */
public class Customer extends BankMaster {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Customer customer = new Customer();
        System.out.println("Choose Action");
        System.out.println("1.View Balance");
        System.out.println("2.Cash Deposit");
        System.out.println("3.Cash Withdrawl");
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Current Balance is : ");
                customer.viewBalance();
                break;
            case 2:
                System.out.println("Enter amount to deposit ");
                double amount = sc.nextDouble();
                customer.deposit(amount);
                break;
            case 3:
                System.out.println("Enter amount to withdraw ");
                double withdraw = sc.nextDouble();
                try {
                    customer.withdraw(withdraw);
                } catch (InsufficientBalException e) {
                   System.out.println(e);
                }
                break;
            default:
                System.out.println("Invalid Action");
                break;
        }
        sc.close();
    }

}
