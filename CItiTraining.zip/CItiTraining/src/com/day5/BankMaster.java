package com.day5;

/**
 * @author yash.ghawghawe
 *
 */
public abstract class BankMaster implements IBankMaster {

	private static double balance = 5000;

	@Override
	public void deposit(double amount) {
		System.out.println("Deposited amount is : " + amount);
		balance = balance + amount;
		System.out.println("Balance after Deposit " + viewBalance());
	}

	@Override
	public void withdraw(double amount) throws InsufficientBalException {
		if (amount > balance) {
			throw new InsufficientBalException("Balance is low For Withdrawl");
		} else {
			this.balance = this.balance - amount;
			System.out.println("Withdrawl is Successful : " + amount);
			System.out.println("Balance after Withdrawl " + viewBalance());
		}

	}

	public double viewBalance() {
		System.out.println("Current Balance is : " + this.balance);
		return this.balance;
	}

}