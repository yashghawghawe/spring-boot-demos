package com.weekend2;

import java.util.Scanner;

/**
 * @author yash.ghawghawe
 *
 */
public class DoubleSlice {//326-145-12
   
    public static int solution(int [] a) {
        int n = a.length;
        int k1[]= new int[n];
        int k2[]= new int[n];
        int max = 0;
        for (int i = 1; i < k1.length-1; i++) {
            k1[i] = Math.max(k1[i-1] + a[i], 0);
        }
        for (int i = n-2; i > 0; i--) {
            k2[i] = Math.max(k2[i+1] + a[i], 0);
        }
        for (int i = 1; i < k2.length-1; i++) {
            max = Math.max(max, k1[i-1]+k2[i+1]);
        }
        return max;
       
    }
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int result = solution(arr);
        System.out.println(result);
        sc.close();
    }

}
