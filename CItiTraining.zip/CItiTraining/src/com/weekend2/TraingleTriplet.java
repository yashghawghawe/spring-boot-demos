package com.weekend2;

import java.util.Arrays;
import java.util.Scanner;

public class TraingleTriplet {
    
    public static void main(String[] args) {//12581020
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int result = solution(arr);
        System.out.println(result);
        sc.close();
    }

    private static int solution(int[] a) {
        Arrays.sort(a);
        for (int i = 0; i < a.length-2; i++) {
            if (a[i] + a[i+1] > a[i+2]) {
                return 1;
            }if(a[i] == a[i+2] && a[i+2] == a[i+1] 
                    && a[i] == Integer.MAX_VALUE){
                return 1;
            }
        }
       return 0;
    }
}
