package com.weekend2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Scanner;

/**
 * @author yash.ghawghawe
 *
 */
public class Permutation {
    //A permutation is a sequence containing each element from 1 to N once, and only once.
    public static int solution(int a[]) {

        Arrays.sort(a);
        LinkedHashSet<Integer> set = new LinkedHashSet<>();
        for (int i = 0; i < a.length; i++) {
            set.add(a[i]);
        }
        ArrayList<Integer> list = new ArrayList<>(set);
        int list_size = list.size();
        if (list_size != a.length || list.get(0) != 1 || list.get(list_size - 1) != a.length) {
            return 0;
        }
        return 1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int result = solution(arr);
        System.out.println(result);
        sc.close();
    }
}
