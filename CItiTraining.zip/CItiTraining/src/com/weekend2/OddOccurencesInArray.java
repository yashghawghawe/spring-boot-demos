package com.weekend2;

import java.util.LinkedHashMap;
import java.util.Scanner;
import java.util.Set;

/**
 * @author yash.ghawghawe
 *
 */
public class OddOccurencesInArray {
   
    public static int solution(int a[]) {
        LinkedHashMap<Integer, Integer> map = new LinkedHashMap<>();
        for (int i = 0; i < a.length; i++) {
            if (map.containsKey(a[i])) {
                int count = map.get(a[i]);
                count++;
                map.put(a[i], count);
            }else {
                map.put(a[i], 1);
            }
        }
        Set<Integer> set = map.keySet();
        for (Integer key : set) {
            int times  = map.get(key);
            if (times % 2 != 0) {
                return key;
            }
        }
        return 0;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int result = solution(arr);
        System.out.println(result);
        sc.close();
    }
}
