package com.weekend2;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author yash.ghawghawe
 *
 */
public class SmallestInteger {

    public static int solution(int[] a) {
        Arrays.sort(a);
        int min = 1;
        for (int i = 0; i < a.length; i++) {
            if (a[i] == min) {
                min++;
            }
        }
        return min;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int result = solution(arr);
        System.out.println(result);
        sc.close();
    }
}
