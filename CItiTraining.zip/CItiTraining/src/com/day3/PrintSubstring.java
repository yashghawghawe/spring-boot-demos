package com.day3;

import java.util.Scanner;

public class PrintSubstring {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the Word : ");
        String word = sc.next();
        System.out.println("Enter two numbers : ");
        int n1 = sc.nextInt();
        int n2 = sc.nextInt();        
        String result = word.substring(n1, n2);
        System.out.println(result);
        sc.close();
    }

}
