package com.day3;

public class PartTimeEmp extends Employee {
    private int payperday;
    private String jobTitle;
    private double workDuration;

    public int getPayperday() {
        return payperday;
    }

    public void setPayperday(int payperday) {
        this.payperday = payperday;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public double getWorkDuration() {
        return workDuration;
    }

    public void setWorkDuration(double workDuration) {
        this.workDuration = workDuration;
    }
    
    public void display(){
        viewData();
        System.out.println("Full time Employee Details : "+getPayperday()+" "+getJobTitle()+
                " "+getWorkDuration());
    }

}
