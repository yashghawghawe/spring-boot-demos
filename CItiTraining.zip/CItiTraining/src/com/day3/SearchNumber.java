package com.day3;

import java.util.Scanner;

public class SearchNumber {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arr[] = { 4, 5, 8, 1, 2, 3, 9, 7, 6, 10 };
        System.out.println("Enter the number to search between 1 to 10");
        int search = sc.nextInt();
        boolean foundIt = false;
        
        for (int number : arr) {
            if (number == search) {
                foundIt = true;
            }
        }
        System.out.println("Number was searched Successfully : "+foundIt);
        sc.close();

    }

}
