package com.day3;

import java.util.Scanner;

public class StringAndCharacter {

    public static String reshape(String word, String character) {
        String convert = "";
        StringBuilder builder = new StringBuilder(word);
        builder.reverse().toString();
        for (int i = 0; i < builder.length(); i++) {
            convert += builder.charAt(i) + character;
        }
        int n = convert.length();
        String result = convert.substring(0, n - 1);
        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String word = sc.next();
        String character = "-";
        String result = reshape(word, character);
        System.out.println(result);
        sc.close();
    }
}
