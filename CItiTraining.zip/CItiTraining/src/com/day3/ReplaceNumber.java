package com.day3;

import java.util.Scanner;

public class ReplaceNumber {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String number[] = sc.nextLine().split("");
        for (int i = 0; i < number.length; i++) {
            if (i < 8) {
                System.out.print("x");
            }else{
                System.out.print(number[i]);
            }
        }
        sc.close();
    }

}
