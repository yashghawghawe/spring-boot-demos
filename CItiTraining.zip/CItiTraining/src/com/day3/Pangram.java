package com.day3;

public class Pangram {

    public static void main(String[] args) {
        String pangram = "The quick brown fox jumps over the lazy dog sp";
        if (checkPangram(pangram))
            System.out.println("Pangram");
        else
            System.out.println("Not a Pangram");
    }

    private static boolean checkPangram(String pangram) {
        boolean alphabet[] = new boolean[26];
        int index = 0;
        pangram = pangram.toUpperCase();
        for (int i = 0; i < pangram.length(); i++) {
            if (pangram.charAt(i) >= 'A' && pangram.charAt(i) <= 'Z') {
                index = pangram.charAt(i) - 'A';
                alphabet[index] = true;
            }
        }
        for (boolean value : alphabet) {
            if (!value)
                return false;
        }
        return true;
    }
}
