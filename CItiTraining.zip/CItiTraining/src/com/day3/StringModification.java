package com.day3;

import java.util.Scanner;

public class StringModification {
    public static String getString(String word) {
        String modifiedWord = word.substring(2, word.length());
        if (word.charAt(0) == 'k') {
            if (word.charAt(1) == 'b') {
                modifiedWord = word.charAt(1) + modifiedWord;
            }
            return modifiedWord = word.charAt(0) + modifiedWord;
        } else if (word.charAt(1) == 'b') {
            return modifiedWord = word.charAt(1) + modifiedWord;
        } else {
            return modifiedWord;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter The word : ");
        String word = sc.next();
        String result = getString(word);
        System.out.println(result);
        sc.close();
    }

}
