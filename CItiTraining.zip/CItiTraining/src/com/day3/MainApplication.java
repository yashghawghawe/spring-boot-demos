package com.day3;

public class MainApplication {

    public static void main(String[] args) {
        FullTimeEmp fte = new FullTimeEmp();
        fte.setName("Yash");
        fte.setEmpid(101);
        fte.setSalary(20000);
        fte.setJobTitle("Developer");
        fte.setAllowance(2000);
        fte.setDecuctions(1500);

        PartTimeEmp pte = new PartTimeEmp();
        pte.setName("Rahul");
        pte.setEmpid(202);
        pte.setJobTitle("DBA");
        pte.setPayperday(5000);
        pte.setWorkDuration(8);

        fte.display();
        pte.display();

    }

}
