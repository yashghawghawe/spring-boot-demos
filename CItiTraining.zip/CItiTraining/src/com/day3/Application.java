package com.day3;

public class Application {

    public static void main(String[] args) {
        Login login = new Login();
        login.setCallTime(2);
        login.setUserName("YashRaj");
        login.setPassWord("Yash5555");
        login.display();

    }

}
