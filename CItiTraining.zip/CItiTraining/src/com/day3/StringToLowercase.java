package com.day3;

import java.util.Scanner;

public class StringToLowercase {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Word : ");
        String word  = sc.next();
        System.out.println("Without Conversion : "+word);
        String converted = word.toLowerCase();
        System.out.println(converted);
        sc.close();

    }

}
