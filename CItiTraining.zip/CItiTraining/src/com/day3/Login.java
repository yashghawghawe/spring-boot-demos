package com.day3;

public class Login extends User {
    private int callTime;

    public int getCallTime() {
        return callTime;
    }

    public void setCallTime(int callTime) {
        this.callTime = callTime;
    }
    
    public void display(){
        System.out.println("Username : "+getUserName()+" Password : "+getPassWord() +" "+getCallTime());
    }

}
