package com.day3;

import java.util.Scanner;

public class ReplaceCharacters {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String word = sc.nextLine();
        System.out.println("Before conversion : " + word);

        String convert = word.replace('d', 'h');
        System.out.println(convert);
        sc.close();

    }

}
