package com.day3;

public class FullTimeEmp extends Employee{
    private double salary;
    private String jobTitle;
    private double allowance;
    private double decuctions;

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public double getAllowance() {
        return allowance;
    }

    public void setAllowance(double allowance) {
        this.allowance = allowance;
    }

    public double getDecuctions() {
        return decuctions;
    }

    public void setDecuctions(double decuctions) {
        this.decuctions = decuctions;
    }
    
    public void display(){
        viewData();
        System.out.println("Full time Employee Details : "+getSalary()+" "+getJobTitle()+
                " "+getAllowance()+" "+getDecuctions());
    }

}
