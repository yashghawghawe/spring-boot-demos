package com.collection;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class Average {

    public static void main(String[] args) {
        int sum = 0,total=0,count=0;
        Scanner sc = new Scanner(System.in);
        HashMap<Integer, Integer> map = new HashMap<>();
        int size = sc.nextInt();
        for (int i = 0; i < size; i++) {
            map.put(sc.nextInt(), sc.nextInt());
        }
        Set<Integer> keys = map.keySet();
        for (Integer key : keys) {
            if (key % 2 != 0) {
                count++;
                sum = sum + map.get(key);
                total = sum / count;
            }
        }
        System.out.println(total);
        sc.close();
    }
}
