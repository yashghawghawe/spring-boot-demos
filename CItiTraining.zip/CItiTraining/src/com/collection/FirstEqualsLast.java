package com.collection;

import java.util.LinkedList;
import java.util.Scanner;

public class FirstEqualsLast {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String sentence = sc.nextLine();
        int result = check(sentence);
        System.out.println(result);
        sc.close();
    }

    private static int check(String sentence) {
        String[] words = sentence.split(" ");
        int n = 0,  sum = 0;
        LinkedList<String> list = new LinkedList<>();
        for (int i = 0; i < words.length; i++) {
            list.add(words[i]);
        }
        if (list.getFirst().equals(list.getLast())) {
            return n = list.getFirst().length();
        } else {
            return sum = list.getFirst().length() + list.getLast().length();
        }
    }
}