package com.collection;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class ArraySum {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int array[] = new int[20];
        for (int i = 0; i < size; i++) {
            array[i] = sc.nextInt();
        }
        int result = addUniqueEven(array);
        System.out.println(result);
        sc.close();
    }

    private static int addUniqueEven(int[] array) {
        int sum = 0;
        LinkedHashSet<Integer> list = new LinkedHashSet<>();
        for (int i = 0; i < array.length; i++) {
            list.add(array[i]);
        }
        Iterator<Integer> it = list.iterator();
        while (it.hasNext()) {
            int n = it.next();
            if (n % 2 == 0) {
                sum = sum + n;
            }
        }
        return sum;
    }
}