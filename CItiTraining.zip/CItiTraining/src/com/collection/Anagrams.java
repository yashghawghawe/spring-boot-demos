package com.collection;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class Anagrams {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String first = sc.nextLine();
		String second = sc.nextLine();
		if (first.length() != second.length()) {
			System.out.println("Not anagrams");
		} else {
			LinkedList<Character> firstWord = new LinkedList<>();
			LinkedList<Character> secondWord = new LinkedList<>();

			for (int i = 0; i < first.length(); i++) {
				firstWord.add(first.charAt(i));
			}
			for (int i = 0; i < second.length(); i++) {
				secondWord.add(second.charAt(i));
			}
			Collections.sort(firstWord);
			Collections.sort(secondWord);

			if (firstWord.equals(secondWord)) {
				System.out.println("Strings are Angram");
			} else {
				System.out.println("Strings are not Anagram");
			}
		}

		// int result = getAnagrams(first, second);
		// if (result == 1) {
		// System.out.println("Anagrams");
		// }else{
		// System.out.println("Not Angrams");
		// }
		sc.close();
	}

	private static int getAnagrams(String first, String second) {
		if (first.length() != second.length()) {
			return -1;
		}
		char arr1[] = first.toLowerCase().toCharArray();
		char arr2[] = second.toLowerCase().toCharArray();
		
		Arrays.sort(arr1);
		Arrays.sort(arr2);
		for (int i = 0; i < arr2.length; i++) {
			if (arr1[i] != arr2[i]) {
				return -1;
			}
		}
		return 1;
	}
}
