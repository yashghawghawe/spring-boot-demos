package com.collection;

import java.util.ArrayList;
import java.util.Scanner;

public class ElectricityBill {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String old = sc.nextLine();
        String newBill = sc.nextLine();
        int result = getElectricityBill(old, newBill);
        System.out.println(result);
        sc.close();
    }

    private static int getElectricityBill(String old, String newBill) {
        ArrayList<String> readings = new ArrayList<>();
        readings.add(old);
        readings.add(newBill);
        int bill = (Integer.parseInt(readings.get(1).substring(5, readings.get(1).length())) -
                Integer.parseInt(readings.get(0).substring(5, readings.get(0).length()))) * 4;
        return bill;
    }

}
