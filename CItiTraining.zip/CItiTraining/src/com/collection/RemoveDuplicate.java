package com.collection;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class RemoveDuplicate {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String sentence = sc.nextLine();
        String result = removeDuplicates(sentence);
        System.out.println(result);
        sc.close();
    }

    private static String removeDuplicates(String sentence) {
        String modified = "";
        LinkedHashSet<Character> list = new LinkedHashSet<>();
        for (int i = 0; i < sentence.length(); i++) {
            list.add(sentence.charAt(i));
        }
        Iterator<Character> it = list.iterator();
        while (it.hasNext()) {
            Character result = it.next();
            modified = modified + result;
        }
        return modified;
    }

}
