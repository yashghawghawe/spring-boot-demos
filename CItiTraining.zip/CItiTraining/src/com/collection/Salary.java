package com.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Salary {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HashMap<Integer, String> map = new HashMap<>();
        HashMap<Integer, Integer> map2 = new HashMap<>();
        int size = sc.nextInt();
        for (int i = 0; i < size; i++) {
            int id =sc.nextInt();
            map.put(id, sc.next());
            map2.put(id, sc.nextInt());
        }
        HashMap<Integer, Integer> result = increaseSalaries(map, map2);
        Iterator it = result.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Integer> entry = (Map.Entry<Integer, Integer>) it.next();
            System.out.println(entry.getKey());
            System.out.println(entry.getValue());
        }
        sc.close();
    }

    private static HashMap<Integer, Integer> increaseSalaries(HashMap<Integer, String> map,
            HashMap<Integer, Integer> map2) {
        Iterator<Integer> it = map.keySet().iterator();
        Iterator<Integer> it2 = map2.values().iterator();
        HashMap<Integer, Integer> result = new HashMap<>();
        while (it.hasNext()) {
            int id = it.next();
           // String desig = map.get(id);
            int salary = it2.next();
            if (map.get(id).equalsIgnoreCase("manager")) {
                result.put(id, salary+5000);
            }
        }
        return result;
    }
}
