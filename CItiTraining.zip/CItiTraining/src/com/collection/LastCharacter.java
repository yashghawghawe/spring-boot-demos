package com.collection;

import java.util.LinkedList;
import java.util.Scanner;

public class LastCharacter {

    public static String concatCharacter(String arr[]) {
        String formattedWord = "";
        LinkedList<String> list = new LinkedList<>();
        for (int i = 0; i < arr.length; i++) {
            list.add(arr[i]);
        }
        for (int i = 0; i < list.size(); i++) {
            char last = list.get(i).charAt(list.get(i).length() - 1);
            formattedWord = formattedWord + last;
        }
        return formattedWord;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        String word[] = new String[size];
        for (int i = 0; i < word.length; i++) {
            word[i] = sc.next();
        }
        String result = concatCharacter(word);
        System.out.println(result);
        sc.close();
    }
}
