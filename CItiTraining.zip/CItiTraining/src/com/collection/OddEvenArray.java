package com.collection;

import java.util.ArrayList;
import java.util.Scanner;

public class OddEvenArray {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        ArrayList<Integer> al = new ArrayList<>();
        ArrayList<Integer> list = new ArrayList<>();
        ArrayList<Integer> result = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            al.add(sc.nextInt());
        }
        for (int i = 0; i < size; i++) {
            list.add(sc.nextInt());
        }
        for (int i = 0; i < size; i++) {
            if (al.get(i)%2 != 0) {
                result.add(al.get(i));
            }else if(list.get(i) %2 == 0){
                result.add(list.get(i));
            }
        }
        System.out.println(result);
        sc.close();
    }
}
