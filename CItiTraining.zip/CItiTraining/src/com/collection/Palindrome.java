package com.collection;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class Palindrome {

    private static int checkPalindrome(String str) {
        StringBuilder builder = new StringBuilder(str);
        int count = 0;
        String reversed = builder.reverse().toString();
        LinkedHashSet<Character> list = new LinkedHashSet<>();
        if (str.equals(reversed)) {
            String lower = reversed.toLowerCase();
            for (int i = 0; i < lower.length(); i++) {
                list.add(lower.charAt(i));
            }
        }
        Iterator<Character> it = list.iterator();
        while (it.hasNext()) {
            Character ch = it.next();
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                count++;
            }
        }
        if (count >= 2) {
            return 1;
        } else {
            return -1;}
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.next();
        int result = checkPalindrome(str);
        if (result == 1) {
            System.out.println("Valid");
        } else {
            System.out.println("Invalid");
        }
        sc.close();
    }
}