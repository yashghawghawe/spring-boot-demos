package com.day821;

public class Ladder {
    public static int[] solution(int[] A, int[] B) {
        int L = A.length;

        int Fib[] = new int[L + 1];
        Fib[0] = 1;
        Fib[1] = 1;

        for (int i = 2; i < L + 1; ++i) {
            Fib[i] = (Fib[i - 1] + Fib[i - 2]) % (1 << 30);//2 power 30

        }

        int result[] = new int[L];
        for (int i = 0; i < L; ++i) {

            result[i] = Fib[A[i]] % (1 << B[i]);//2 power b[i]
        }

        return result;
    }

    public static void main(String[] args) {
        int A[] = new int[] { 4, 4, 5, 5, 1 };
        int B[] = new int[] { 3, 2, 4, 3, 1 };
        for (int arr : solution(A, B)) {
            System.out.println(arr);
        } 
    }
}
