package com.day821;

import java.util.Scanner;

public class ChocolatesByNumbers {

    public static int PrintChocolates(int N, int M)
    {
        int start = 0, value = 0, count = 1;
        while ((start + M)% N != 0) {
            value = (start + M)% N ;
            start = value;
            count++;
        }
        return count;
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int M = sc.nextInt();
        System.out.println(PrintChocolates(N, M));
        sc.close();
    }
}
