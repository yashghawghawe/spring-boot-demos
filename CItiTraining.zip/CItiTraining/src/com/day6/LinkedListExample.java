package com.day6;

import java.util.Iterator;
import java.util.LinkedList;

/**
 * @author yash.ghawghawe
 *
 */
public class LinkedListExample {

    public static void main(String[] args) {
        LinkedList<Integer> list = new LinkedList<>();
        for (int i = 1; i <= 9; i++) {
            list.add(i);
        }
        
        Iterator<Integer> i  = list.iterator();
        while (i.hasNext()) {
            Integer integer = (Integer) i.next();
            if (integer %2 == 0) {
                System.out.println(integer);
            }
        }

        //display  first and last elements
        System.out.println(list.getFirst() + " " + list.getLast());

        //display delete middle element
        System.out.println(list.remove(4));

        //display all remaining elements excluding first and last
        System.out.println(list.subList(1, 7));
    }

}
