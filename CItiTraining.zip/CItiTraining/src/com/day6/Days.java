package com.day6;

/**
 * @author yash.ghawghawe
 *
 */
public class Days extends Thread {

    static SalesPerson person = new SalesPerson();

    @SuppressWarnings("deprecation")
    public void run() {
        String Days[] = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
        for (int i = 0; i < Days.length; i++) {
            if (Days[i] != "Sunday") {
                System.out.println(Days[i]);
            } else {
                person.suspend();
                if (Days[i] == "Wednesday") {
                    person.resume();
                }
            }
        }
    }

    public static void main(String[] args) {
        Days days = new Days();
        days.start();
        person.start();
    }

}
