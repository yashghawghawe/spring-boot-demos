package com.day6;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * @author yash.ghawghawe
 *
 */
public class DuplicateCharacter {
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        Map<Character, Integer> map = new HashMap<Character, Integer>();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (map.containsKey(ch)) {
                int count = map.get(ch);
                map.put(ch, ++count);
            } else {
                map.put(ch, 1);
            }
        }
        Set<Character> keys = map.keySet();  
        for (Character ch : keys) {  
            if (map.get(ch) > 1) {  
                System.out.println(ch + " is occuring " + map.get(ch) + " times");  
            }  
        }
        sc.close();
    }

}