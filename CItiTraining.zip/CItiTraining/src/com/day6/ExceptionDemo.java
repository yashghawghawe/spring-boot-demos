package com.day6;

public class ExceptionDemo {

    public static void main(String[] args) {
        System.out.println(tryCatchFinally());
    }

    static String tryCatchFinally() {
        try {
            throw new Exception();
            //            return "try";
        } catch (Exception e) {
            return "catch";
        } finally {
            return "returnning finally";
        }
    }

}
