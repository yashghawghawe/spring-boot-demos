package com.day6;

import java.util.Iterator;
import java.util.TreeSet;

/**
 * @author yash.ghawghawe
 *
 */
public class TreesetSorting {

    public static void main(String[] args) {
        TreeSet<Product> products = new TreeSet<Product>();
        products.add(new Product(1, "Mobile", 15000));
        products.add(new Product(4, "Football", 600));
        products.add(new Product(3, "TV", 40000));
        products.add(new Product(2, "Laptop", 50000));

        for (Product product : products) {
            System.out.println(product);
        }
        System.out.println();
        Iterator<Product> itr = products.descendingIterator();
        while (itr.hasNext()) {
            Product product = (Product) itr.next();
            System.out.println(product);
        }
    }

}
