package com.day6;

/**
 * @author yash.ghawghawe
 *
 */
public class Product implements Comparable<Product> {

    private int serialNumber;
    private String name;
    private double price;

    public Product(int serialNumber, String name, double price) {
        this.serialNumber = serialNumber;
        this.name = name;
        this.price = price;
    }

    @Override
    public int compareTo(Product o) {
        int sn1 = this.serialNumber;
        int sn2 = ((Product) o).serialNumber;
        if (sn1 < sn2) {
            return -1;
        } else if (sn1 > sn2) {
            return 1;
        } else
            return 0;
    }

    @Override
    public String toString() {
        return "Product [serialNumber=" + serialNumber + ", name=" + name + ", price=" + price + "]";
    }

}