package com.day6;

import java.util.Scanner;

/**
 * @author yash.ghawghawe
 *
 */
public class UserAccount implements Userlogin {
    static Scanner sc = new Scanner(System.in);

    @Override
    public void login(String username, String password) throws InvalidUserAccountException {
        if (username.matches("[a-zA-Z0-9]{6,7}")) {
            if (password.matches("^[A-Z][a-z]+$")) {// \\d{3}[-]\\d{3}[-]\\d{4}
                System.out.println("Username and Password Validated Successfully");
            }else {
                throw new InvalidUserAccountException("invalid username or password ");
            }
        }else {
            throw new InvalidUserAccountException("invalid username or password ");
        }
    }

    public static void main(String[] args) {
        System.out.print("Enter Username : ");
        String username = sc.nextLine();
        System.out.print("Enter Password : ");
        String password = sc.nextLine();
        UserAccount account = new UserAccount();
        try {
            account.login(username, password);
        } catch (InvalidUserAccountException e) {
            System.out.println(e);
        }
    }

}
