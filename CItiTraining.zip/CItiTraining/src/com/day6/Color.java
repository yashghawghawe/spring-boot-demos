package com.day6;

import java.util.Random;

/**
 * @author yash.ghawghawe
 *
 */
public class Color extends Thread {

    static Color color = new Color();

    @SuppressWarnings("deprecation")
    public void run() {
        String colors[] = { "white", "blue", "black", "green", "red", "yellow" };
        Random random = new Random();
        for (int i = 0; i < colors.length; i++) {
            i = random.nextInt(colors.length);
            if (colors[i] != "red") {
                System.out.println(colors[i]);
            } else {
                color.stop();
            }

        }
    }

    public static void main(String[] args) {
        color.start();
    }

}
