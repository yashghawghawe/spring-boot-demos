package com.day6;

/**
 * @author yash.ghawghawe
 *
 */
public interface Userlogin {

    void login(String username, String password) throws InvalidUserAccountException;

}