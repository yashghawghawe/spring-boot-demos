package com.day6;

/**
 * @author yash.ghawghawe
 *
 */
public class SalesPerson extends Thread {
   
    public void run() {
        String persons[] = {"Yash","Sanket","Kartik","Prem","Rahul"};
        for (int i = 0; i < persons.length; i++) {
            System.out.println(persons[i]);
        }
    }

}