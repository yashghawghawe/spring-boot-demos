package com.day6;

/**
 * @author yash.ghawghawe
 *
 */
public class InvalidUserAccountException extends Exception {

    private static final long serialVersionUID = 1L;
    String str;

    public InvalidUserAccountException(String str) {
        this.str = str;
    }

    public String toString() {
        return str;

    }
}