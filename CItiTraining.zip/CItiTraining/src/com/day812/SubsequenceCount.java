package com.day812;

import java.util.Scanner;

public class SubsequenceCount {

    public static int getSubsequences(String subsequence, String string) {
        int count = 0;
        char[] sub = subsequence.toCharArray();//ABC
        char[] str = string.toCharArray();//ABCBABC
        String str1= (String) string.subSequence(0, 3);
        for (int i = 0; i < str.length; i++) {
            if (str[i] == sub[0]) {
                for (int j = i + 1; j < str.length; j++) {
                    if (str[j] == sub[1]) {
                        for (int k = j + 1; k < str.length; k++) {
                            if (str[k] == sub[2]) {
                                count++;
                            }
                        }
                    }
                }
            }
        }
        return count;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String subsequence = sc.next();
        String string = sc.next();
        int result2 = getSubsequences(subsequence, string);
        System.out.println(result2);
        sc.close();
    }

}
