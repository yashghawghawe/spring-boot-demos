package com.day812;

import java.util.Scanner;

public class Flips {
    public static int minFlips(String target) {

        char curr = '1';
        int count = 0;
        for (int i = 0; i < target.length(); i++) {

            if (target.charAt(i) == curr) {

                count++;
                curr = (char) (48 + (curr + 1) % 2);
            }
        }
        return count;
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int result = minFlips(sc.next());
        System.out.println(result);
        sc.close();
    }
}
