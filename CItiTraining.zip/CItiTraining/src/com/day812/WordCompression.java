package com.day812;

import java.util.HashMap;

public class WordCompression {

    public static void main(String[] args) {
        String s = "abbcccb";
        int k = 3;
        System.out.println(compressWord(s, k));
    }

    public static String compressWord(String word, int k) {
        StringBuffer s = new StringBuffer(word);
        char prev;
        HashMap<Character, Integer> m = new HashMap<>();
        for (int i = 0; i < s.length(); i++) {
            if (i == 0) {
                prev = s.charAt(i);
                continue;
            } else {
                m.put(s.charAt(i), m.get(s.charAt(i)) == null ? 1 : m.get(s.charAt(i)) + 1);
                if (m.get(s.charAt(i)) == k) {
                    s.deleteCharAt(i);
                    s.deleteCharAt(i - 1);
                    s.deleteCharAt(i - 2);
                    return compressWord(s.toString(), k);
                }
            }
        }
        return s.toString();
    }
}
