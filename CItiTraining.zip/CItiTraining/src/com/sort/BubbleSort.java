package com.sort;

public class BubbleSort {
    public static void bubbleSort(int[] input) {
        int n = input.length;
        for (int i = 0; i < n - 1; i++) {
            boolean swapped = true;
            // i represents how many elements have bubbled to correct place
            for (int j = 0; j < n -1-i; j++) {
                if (input[j] > input[j + 1]) {
                    //swap
                    int temp = input[j];
                    input[j] = input[j + 1];
                    input[j + 1] = temp;
                    swapped = false;
                }
            }
            if(swapped)break;
        }
    }

    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + ", ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        //initialize
        int[] input = { 10, 8, 1, 88, 64, 21, 19, 4, 3, 2 };
        //sort
        bubbleSort(input);
        //print
        printArray(input);
    }

}
