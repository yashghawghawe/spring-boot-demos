package com.sort;

import java.util.Scanner;
import java.util.Stack;

public class DecimalBinaryExample {

    public static void main(String a[]) {
        //Predefined method
        System.out.println("Binary representation of 124: ");
        System.out.println(Integer.toBinaryString(124));
        System.out.println("\nBinary representation of 45: ");
        System.out.println(Integer.toBinaryString(45));
        System.out.println("\nBinary representation of 999: ");
        System.out.println(Integer.toBinaryString(999));
        
        Scanner in = new Scanner(System.in);
        
        // Create Stack object
        Stack<Integer> stack = new Stack<Integer>();
     
        // User input 
        System.out.println("Enter decimal number: ");
        int num = in.nextInt();
     
        while (num != 0)
        {
          int d = num % 2;
          stack.push(d);
          num /= 2;
        } 
     
        System.out.print("\nBinary representation is:");
        while (!(stack.isEmpty() ))
        {
          System.out.print(stack.pop());
        }
        System.out.println();
    }
}
