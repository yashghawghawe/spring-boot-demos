package com.sort;

public class BinarySearch {
    
    public static int solution(int a[],int first,int last,int key){
        while(first <= last){
            int mid = (first+last)/2;
            if (key == a[mid]) {
                return mid;
            }else if(key < a[mid]){
                last = mid-1;
            }else{
                first = mid +1;
            }            
        }if(first>last){
            System.out.println("Element is not found");
        }
        return 0;
    }
    public static void main(String[] args) {
        int arr[] = {6,8,10,15,17,18,20};
        int key = 10;
        int first = 1;
        int last = arr.length;
        int result = solution(arr, first, last, key);
        System.out.println(result);
    }

}
