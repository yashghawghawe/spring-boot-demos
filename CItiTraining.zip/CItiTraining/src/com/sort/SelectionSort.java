package com.sort;

public class SelectionSort {

    public static void selectionSort(int[] a) {
        for (int i = 0; i < a.length-1; i++) {
            int minIndex = i;
            for (int j = i; j < a.length-1; j++) {
                if (a[j] < a[minIndex] ) {
                    minIndex = j;
                }
            }
            int temp = a[i];
            a[i] = a[minIndex];
            a[minIndex] = temp;
        }
        for (int i : a) {
            System.out.print(i+" ");
        }
    }

    public static void main(String[] args) {
        //initialize
        int[] input = { 10, 8, 1, 88, 64, 21, 19, 4, 3, 2 };
        //sort
        selectionSort(input);
    }
}
