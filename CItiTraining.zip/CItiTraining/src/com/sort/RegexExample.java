package com.sort;

import java.util.regex.Pattern;

public class RegexExample {

    public static void main(String[] args) {
        String[] password = { "Ankit@463", "ankit@123", "ankit@12", "ankit@1023", "Ankt@123", "Lent@asd011",
                "Lengt@009", "Length@010", "Len@007", "Ankiit@007" };
        for (String string : password) {
            System.out.println(string + " > " + Pattern.matches("[A-Z]{1}[A-Za-z@]{5,7}[\\d]{3}$", string));
        }

    }

}
