package com.day811;

import java.util.Scanner;
import java.util.Stack;

public class StackExample {
    public static int solution(String s) {
        Stack<Character> stack = new Stack<>();
        char[] ch = s.toCharArray();
        for (int i = 0; i < ch.length; i++) {
            if (ch[i] == '(' || ch[i] == '[' || ch[i] == '{') {
                stack.push(ch[i]);
            } else {
                if (stack.isEmpty())
                    return 0;
                switch (ch[i]) {
                    case ')':
                        if (stack.peek() == '(')
                            stack.pop();
                        else return 0;
                        break;
                    case ']':
                        if (stack.peek() == '[')
                            stack.pop();
                        else return 0;
                        break;
                    case '}':
                        if (stack.peek() == '{')
                            stack.pop();
                        else return 0;
                        break;
                    default:
                        break;
                }
            }
        }
        return stack.empty() ? 1:0;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String format = sc.next();
        int result = solution(format);
        System.out.println(result);
        sc.close();
    }
}
