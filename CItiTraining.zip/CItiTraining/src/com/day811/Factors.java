package com.day811;

import java.util.Scanner;

public class Factors {
    
    public static int solution(int n){
        int result = 0;
        int i =1;
        while (i*i < n) {
            if (n%i == 0) {
                result += 2;
                i += 1;
            }else if(n%i != 0){
                i += 1;
            }
        }
        if (i*i==n) {
            result += 1;
        }
        return result;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n =sc.nextInt();
        int result = solution(n);
        System.out.println(result);
        sc.close();
    }
}
