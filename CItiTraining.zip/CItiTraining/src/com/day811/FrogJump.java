package com.day811;

import java.util.Scanner;

public class FrogJump {
    public static int solution(int X, int Y, int D) {
        int distance = Y - X;
        int jumps = distance / D;
        if (distance % D != 0) {
            jumps++;
        }
        return jumps;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int initial = sc.nextInt();
        int target = sc.nextInt();
        int jumpDistance = sc.nextInt();
        int result = solution(initial, target, jumpDistance);
        System.out.println(result);
        sc.close();
    }

}
