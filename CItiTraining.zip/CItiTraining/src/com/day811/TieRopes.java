package com.day811;

public class TieRopes {
    public static void main(String[] args) {
        int arr[]={1,2,3,4,1,1,3};
        int k =4;
        int result = solution(arr,k);
        System.out.println(result);
    }

    private static int solution(int[] arr, int k) {
        int length = 0;
        int result = 0;
        for (int rope : arr) {
            length = length + rope;
            if (length >= k) {
                result++;
                length = 0;
            }
        }
        return result;
    }
}
