package com.day817;

import java.util.HashMap;
import java.util.Scanner;

public class WordCompression {

    public static String solution(String s, int k) {
        StringBuffer sb = new StringBuffer(s);
        HashMap<Character, Integer> map = new HashMap<>();
        char prev;
        for (int i = 0; i < s.length(); i++) {
            if (i == 0) {
                prev = sb.charAt(i);
                continue;
            } else {
                map.put(sb.charAt(i), map.get(sb.charAt(i)) == null ? 1 : map.get(sb.charAt(i)) + 1);
                if (map.get(sb.charAt(i)) == k) {
                    sb.deleteCharAt(i);
                    sb.deleteCharAt(i - 1);
                    sb.deleteCharAt(i - 2);
                    return solution(sb.toString(), k);
                }
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String word = sc.next();
        int k = sc.nextInt();
        String result = solution(word, k);
        System.out.println(result);
        sc.close();
    }

}
