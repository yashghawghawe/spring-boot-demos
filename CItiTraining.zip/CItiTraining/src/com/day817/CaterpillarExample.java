package com.day817;

public class CaterpillarExample {

    public static boolean solution(int a[], int target) {
        int start = 0;
        int end = a.length - 1;
        int sum = 0;
        while (start < end) {
            sum = a[start] + a[end];
            if (sum == target) {
                return true;
            }else if(sum > target){
                end--;
            }else{
                start++;
            }
        }
        return false;
    }

    public static void main(String[] args) {
       int arr [] =  {2, 7, 11, 15};
       int target = 9;
       boolean result = solution(arr,target);
       System.out.println(result);
    }

}
