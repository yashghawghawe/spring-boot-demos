package com.day817;

import java.util.LinkedHashSet;

public class CommonPrimeDivisors {

    public static int solution(int[] A, int[] B) {
        int n = A.length;
        int result = 0 ;
        for (int i = 0; i < n; i++) {
            if (isSameDivisores(A[i],B[i])) {
                result++;
            }
        }
        return result;
    }

    private static boolean isSameDivisores(int a, int b) {
        LinkedHashSet<Integer> set = new LinkedHashSet<>();
        LinkedHashSet<Integer> set2 = new LinkedHashSet<>();
        for (int i = 2; i <= a; i++) {
            if (a%i==0) {
                set.add(i);
                a= a/ i;
            }
        }
        for (int i = 2; i <= b; i++) {
            if (b%i==0) {
                set2.add(i);
                b = b/i;
            }
        }
        return set.equals(set2) ? true : false;
    }

    public static void main(String[] args) {
        int A[] = new int[] { 15, 10, 3 };
        int B[] = new int[] { 75, 30, 5 };
        System.out.println(solution(A, B));
    }
}
