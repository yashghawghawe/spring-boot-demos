package com.day817;

import java.util.LinkedHashSet;

public class CaterPillarMethod {
    
    public static int solution(int a[]){
        LinkedHashSet<Integer> set = new LinkedHashSet<>();
        for (int i = 0; i < a.length; i++) {
            set.add(Math.abs(a[i]));
        }
        return set.size();
    }

    public static void main(String[] args) {
        int a [] = {-5,-3,-1,0,3,6};
        int result = solution(a);
        System.out.println(result);
    }

}
