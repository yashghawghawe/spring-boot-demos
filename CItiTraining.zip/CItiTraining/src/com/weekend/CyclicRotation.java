package com.weekend;

import java.util.Arrays;
import java.util.Scanner;

public class CyclicRotation {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int arr[] = { 3, 8, 9, 7, 6 };
        int result[] = solution(arr, n);
        System.out.println(Arrays.toString(result));
        sc.close();
    }

    private static int[] solution(int[] arr, int n) {
        int rotatedArray[] = new int[arr.length];
        for (int i = 0; i < rotatedArray.length; i++) {
            int rotatedIndex = (i + n) % arr.length;
            rotatedArray[rotatedIndex] = arr[i];
        }
        return rotatedArray;
    }

}
