package com.weekend;

import java.util.regex.Pattern;

public class Regex {

    public static void main(String[] args) {

        String[] id = new String[] {
                "julia@hackerrank.com", "julia_@hackerrank.com", "julia_0@hackerrank.com",
                "julia0_@hackerrank.com", "julia@gmail.com" };
        for (int i = 0; i <= 4; i++) {

            System.out.println(id[i] + ": " + Pattern.matches("^[a-z]{1,6}_?\\d{0,4}@" + "hackerrank.com", id[i]));

        }
    }
}
