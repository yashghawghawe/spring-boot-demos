package com.weekend;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class MissingWords {
    public static List<String> missingWords(String s, String t) {
        LinkedList<String> list = new LinkedList<>(Arrays.asList(s.split(" ")));
        LinkedList<String> list2 = new LinkedList<>(Arrays.asList(t.split(" ")));
        for (String str : list2) {
            if (list.contains(str)) {
                list.removeFirstOccurrence(str);
            }
        }
        return list;
    }//i am using hackerrank to improve programming
     //am hackerrank to improve

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String first = sc.nextLine();
        String second = sc.nextLine();
        List<String> result = missingWords(first, second);
        for (String string : result) {
            System.out.println(string);
        }
        sc.close();
    }
}
