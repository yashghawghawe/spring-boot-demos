package com.weekend;

public class DivisibleByK {
    public static int solution(int a, int b, int k) {
        int count = 0;
        for (int i = a; i <= b; i++) {
            if (i % k == 0) {
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        int a = 4;
        int b = 12;
        int k = 2;
        int result = solution(a, b, k);
        System.out.println(result);
    }
}
