package com.weekend;

public class PrimeFactorization {

    public int solution(int[] A, int[] B) {
        int ans = 0;
        for (int i = 0; i < A.length; i++) {
            if (common(A[i], B[i])) {
                ans++;
            }
        }
        return ans;
    }

    private boolean common(int x, int y) {
        int d = gcd(x, y);
        return commonGCD(d, x) && commonGCD(d, y);
    }

    private boolean commonGCD(int x, int y) {
        int d = gcd(x, y);
        while (d != 1) {
            y /= d;
            d = gcd(x, y);
        }
        return x % y == 0;
    }

    private int gcd(int n, int m) {
        if (n == 0) {
            return m;
        }
        return gcd(m % n, n);
    }

    public static void main(String[] args) {
        int a[] = { 15, 10, 3 };
        int b[] = { 75, 30, 5 };
        PrimeFactorization factorization = new PrimeFactorization();
        int result = factorization.solution(a, b);
        System.out.println(result);
    }
}
