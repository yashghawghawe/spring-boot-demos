package com.weekend;

public class Block {
    public int solution(int K, int M, int[] A) {

        int minSum = 0;
        int maxSum = 0;
        for (int i = 0; i < A.length; i++) {
            maxSum = maxSum + A[i]; 
            minSum = Math.max(minSum, A[i]); 
        }

        int possibleResult = maxSum;

        while (minSum <= maxSum) {
            int midSum = (minSum + maxSum) / 2;
            boolean ok = checkDivisable(midSum, K, A);
            if (ok == true) {
                possibleResult = midSum;               
                maxSum = midSum - 1;
            } else { 
                minSum = midSum + 1;
            }            
        }
        return possibleResult;
    }

    public boolean checkDivisable(int mid, int k, int[] a) {
        int numBlockAllowed = k;
        int currentBlockSum = 0;

        for (int i = 0; i < a.length; i++) {
            currentBlockSum = currentBlockSum + a[i];
            if (currentBlockSum > mid) {
                numBlockAllowed--;
                currentBlockSum = a[i]; 
            }
            if (numBlockAllowed == 0) {
            }
        }
        return true;
    }
}
