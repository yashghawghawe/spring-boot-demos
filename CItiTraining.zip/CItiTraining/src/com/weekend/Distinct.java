package com.weekend;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class Distinct {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int result = solution(arr);
        System.out.println(result);
        sc.close();
    }

    private static int solution(int[] arr) {
        Arrays.sort(arr);
        LinkedHashSet<Integer> distinct = new LinkedHashSet<>();
        for (int i = 0; i < arr.length; i++) {
            distinct.add(arr[i]);
        }
        return distinct.size();
    }

}
