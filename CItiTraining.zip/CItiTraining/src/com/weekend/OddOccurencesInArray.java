package com.weekend;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class OddOccurencesInArray {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arr[] = { 3, 5, 9, 4, 5, 4, 9 };
        int result = solution(arr);
        System.out.println(result);
        sc.close();
    }

    public static int solution(int arr[]) {
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < arr.length; i++) {
            if (map.containsKey(arr[i])) {
                int count = map.get(arr[i]);
                count++;
                map.put(arr[i], count);
            } else {
                map.put(arr[i], 1);
            }
        }
        Set<Integer> set = map.keySet();
        for (Integer key : set) {
            int occurs = map.get(key);
            if (occurs % 2 != 0)
                return key;
        }
        return 0;
    }
}
