package com.weekend;

public class MissingElement {

    public static int solution(int[] a) {
        int n = a.length;
        int i, total;
        total = (n + 1) * (n + 2) / 2;
        for (i = 0; i < n; i++)
            total = total - a[i];
        return total;
    }

    public static void main(String[] args) {
        int arr[] = { 2, 3, 1, 4, 6 };
        int result = solution(arr);
        System.out.println(result);
    }
}
