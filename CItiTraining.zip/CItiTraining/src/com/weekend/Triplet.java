package com.weekend;

import java.util.Arrays;

public class Triplet {

    public static int solution(int a[]) {
        Arrays.sort(a);
        int max1 = a[a.length - 1] * a[a.length - 2] * a[a.length - 3];
        int max2 = a[0] * a[1] * a[a.length - 1];
        int max = Math.max(max1, max2);
        return max;
    }

    public static void main(String[] args) {
        int arr[] = { -3, 4, 2, 3, 5, 6 };
        int result = solution(arr);
        System.out.println(result);
    }

}
