package com.weekend;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class BinaryRepresentation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String binary = Integer.toBinaryString(sc.nextInt());
        LinkedHashMap<Integer, Character> map = new LinkedHashMap<Integer, Character>();
        int j = 0;
        for (int i = 0; i < binary.length(); i++) {
            j++;
            map.put(j, binary.charAt(i));
        }
        Iterator<Entry<Integer, Character>> it = map.entrySet().iterator();
        int count =0 ;
        while (it.hasNext()) {
            Map.Entry<Integer, Character> e = (Map.Entry<Integer, Character>) it.next();
            if (e.getValue() == '1') {
                count++;
                System.out.println(e.getKey());
            }
        }
        sc.close();
    }
}
