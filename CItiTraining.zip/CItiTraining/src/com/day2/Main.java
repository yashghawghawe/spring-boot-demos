package com.day2;

import java.util.Scanner;

class UserMainCode {
    public static int checkSum(int n) {
        int sum = 0;
        while (n != 0) {
            int remainder = n % 10;
            if (remainder % 2 != 0) {
                sum = sum + remainder;
            }
            n = n / 10;
        }
        if (sum % 2 == 0) {
            System.out.println("Sum of digits is even");
            return -1;
        } else {
            System.out.println("Sum of digits is odd");
            return -1;
        }

    }

}

public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        UserMainCode.checkSum(x);
        sc.close();

    }

}