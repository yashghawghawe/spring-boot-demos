package com.day2;

import java.util.Scanner;

public class SwapVariables {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number to swap ");
        int x = sc.nextInt();
        int y = sc.nextInt();
        int t;
        System.out.println("Numbers before Swapping x = " + x + " y = " + y);

        //swapping
        t = x;
        x = y;
        y = t;

        System.out.println("Numbers after Swapping x = " + x + " y = " + y);
        sc.close();
    }

}
