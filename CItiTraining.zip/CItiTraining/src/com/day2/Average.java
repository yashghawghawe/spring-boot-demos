package com.day2;

import java.util.Scanner;

public class Average {

    public static void main(String[] args) {
        int avg, total;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter three Numbers :");
        int n1 = sc.nextInt();
        int n2 = sc.nextInt();
        int n3 = sc.nextInt();

        total = n1 + n2 + n3;
        avg = total / 3;
        System.out.println("THe average of three given numbers is : " + avg);
        sc.close();
    }

}
