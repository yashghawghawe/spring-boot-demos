package com.day2;

public class OperationResult {

    /**
     * @param args
     */
    public static void main(String[] args) {

        int result1, result2, result3, result4;
        result1 = -5 + 8 * 6;
        System.out.println("Result 1 :" + result1);

        result2 = (55 + 9) % 9;
        System.out.println("Result 2 :" + result2);

        result3 = 20 + -3 * 5 / 8;
        System.out.println("Result 3 :" + result3);

        result4 = 5 + 15 / 3 * 2 - 8 % 3;
        System.out.println("Result 4 :" + result4);

    }

}
