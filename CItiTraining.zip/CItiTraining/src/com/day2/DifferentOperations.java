package com.day2;

public class DifferentOperations {

    /**
     * @param args
     */
    public static void main(String[] args) {
        int num1 = 20, num2 = 4;
        int add=0, minus=0, mul=0, divide=0, remainder=0;

        System.out.println("Addition : " + (add = num1 + num2));
        System.out.println();

        System.out.println("Subtraction :" + (minus = num1 - num2));
        System.out.println();

        System.out.println("Multiplication :" + (mul = num1 * num2));
        System.out.println();

        System.out.println("Division :" + (divide = num1 / num2));
        System.out.println();

        System.out.println("Remainder :" + (remainder = num1 % num2));

    }

}