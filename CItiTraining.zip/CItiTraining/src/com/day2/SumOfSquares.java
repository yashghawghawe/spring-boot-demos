package com.day2;

import java.util.Scanner;

class UserCode {

    public static int checkSumOfSquareOfEvenDigits(int n) {
        int sum = 0;
        while (n != 0) {
            int remainder = n % 10;
            if (remainder % 2 == 0) {
                sum = sum + (int) Math.pow(remainder, 2);
            }
            n = n / 10;
        }
        return sum;
    }
}

public class SumOfSquares {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Number : ");
        int n = sc.nextInt();
        int result = UserCode.checkSumOfSquareOfEvenDigits(n);
        System.out.println(result);
        sc.close();

    }

}