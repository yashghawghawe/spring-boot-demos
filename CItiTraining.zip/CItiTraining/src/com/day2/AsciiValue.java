package com.day2;

import java.util.Scanner;

public class AsciiValue {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a alpbabet : ");
        char ch = sc.next().charAt(0);
        int asciiValue = ch;

        System.out.println("Ascii Value of a given Character " + asciiValue);
        sc.close();

    }

}
