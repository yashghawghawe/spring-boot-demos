package com.day2;

public class My {
    public static void main(String[] args) {
        if (true) {
            // break;
        }
        String s = "Ashu";
        switch (s) {

            default:
                System.out.println("b");
            case "A":
                System.out.println("a");

        }

    }

}
