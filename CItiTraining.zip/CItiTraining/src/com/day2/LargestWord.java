package com.day2;

import java.util.Scanner;

class Word {
    private final static String yash = "YASH";

    public static String getLargestWord(String sentence) {

        String[] word = sentence.split(" ");
        String s = word[0];
        String maxlengthWord = " ";
        for (int i = 0; i < word.length; i++) {
            if (s.length() >= word[i].length()) {
                maxlengthWord = s;
            } else {
                maxlengthWord = word[i];
            }
        }

        return maxlengthWord;

    }

}

public class LargestWord {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String sentence = sc.nextLine();
        String result = Word.getLargestWord(sentence);
        System.out.println(result);
        sc.close();

    }

}