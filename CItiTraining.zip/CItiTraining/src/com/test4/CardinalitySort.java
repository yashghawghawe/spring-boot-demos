package com.test4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class CardinalitySort {

    public static List<Integer> cardinalitySort(List<Integer> nums) {
       Collections.sort(nums,new Comparator<Integer>(){

        @Override
        public int compare(Integer num1, Integer num2) {
            if (num1 == num2) {
                return 1;
            }else if(Integer.bitCount(num1) > Integer.bitCount(num2)){
                return 1;
            }else if (Integer.bitCount(num1) < Integer.bitCount(num2)){
                return -1;
            }else if(Integer.bitCount(num1) == Integer.bitCount(num2)){
                return (num1 > num2) ? 1 : -1; 
            }
            return 0;
        }
           
       });
        return nums;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Integer> arr = new ArrayList<Integer>();
        int size = sc.nextInt();
        for (int i = 0; i < size; i++) {
            arr.add(sc.nextInt());
        }
        List<Integer> result = cardinalitySort(arr);
        System.out.println(result);
        sc.close();
    }
}
