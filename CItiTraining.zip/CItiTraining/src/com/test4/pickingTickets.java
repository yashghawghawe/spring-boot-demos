package com.test4;

import java.util.Arrays;
import java.util.Scanner;

public class pickingTickets {
    public static int tickets(int[] arr) {
        Arrays.sort(arr);
        int temp = 1,count =Integer.MIN_VALUE;
        int max = 0;
        for (int i = 0; i < arr.length-1; i++) {
            if(Math.abs(arr[i+1] - arr[i]) == 0 || Math.abs(arr[i+1] - arr[i]) == 1){
                temp++;
            }else{
                temp = 1;
            }if (count < temp) {
                count = temp;
            }
            max =Math.max(max, temp);
        }
        return max;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int arr[] = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        int result = tickets(arr);
        System.out.println(result);
        sc.close();
    }
}
