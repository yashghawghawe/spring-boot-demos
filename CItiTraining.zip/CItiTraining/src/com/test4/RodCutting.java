package com.test4;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class RodCutting {

    public static List<Integer> rodOffcut(List<Integer> lengths) {
        Collections.sort(lengths);
        LinkedList<Integer> list = new LinkedList<>();
        while (lengths.size() != 0) {
            list.add(lengths.size());
            lengths = cutlength(lengths);
        }
        return list;
    }

    private static List<Integer> cutlength(List<Integer> lengths) {
        LinkedList<Integer> list = new LinkedList<>();
        int smallest = lengths.get(0);
        for (int i = 0; i < lengths.size(); i++) {
            if (lengths.get(i) - smallest > 0) {
                list.add(lengths.get(i) - smallest);
            }
        }
        return list;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Integer> arr = new LinkedList<Integer>();
        int size = sc.nextInt();
        for (int i = 0; i < size; i++) {
            arr.add(sc.nextInt());
        }
        List<Integer> result = rodOffcut(arr);
        System.out.println(result);
        sc.close();
    }
}
