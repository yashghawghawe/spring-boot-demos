package com.test4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GroupingDigits {

    public static int minMoves(List<Integer> arr) {
        int n = arr.size();
        Integer array[] = new Integer[n];
        arr.toArray(array);
        int count = 0;
        for (int i = 0; i < n - 1; i++) {
            boolean swapped = true;
            for (int j = 0; j < n - 1 - i; j++) {
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    count++;
                    swapped = false;
                }
            }
            if (swapped) {
                break;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Integer> arr = new ArrayList<Integer>();
        int size = sc.nextInt();
        for (int i = 0; i < size; i++) {
            arr.add(sc.nextInt());
        }
        int result = minMoves(arr);
        System.out.println(result);
        sc.close();
    }

}
