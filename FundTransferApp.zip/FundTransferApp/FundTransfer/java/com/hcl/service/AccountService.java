package com.hcl.service;

import com.hcl.dto.AccountDTO;

public interface AccountService {

	AccountDTO getAccountDetails(int userid);

}
