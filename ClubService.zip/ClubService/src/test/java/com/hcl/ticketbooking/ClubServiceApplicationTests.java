package com.hcl.ticketbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClubServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
