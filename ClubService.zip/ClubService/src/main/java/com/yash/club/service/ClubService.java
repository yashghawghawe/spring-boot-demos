package com.yash.club.service;

import java.util.List;

import com.yash.club.dto.ClubRequest;
import com.yash.club.dto.ClubResponse;

public interface ClubService {

	ClubResponse saveClub(ClubRequest clubRequest);

	List<ClubResponse> getClubsByPlayerId(int playerId);

	List<ClubResponse> getClubsByPlayerIdAsRequestParam(int playerId);

	List<ClubResponse> postClubByPlayerId(ClubRequest clubRequest);

}
