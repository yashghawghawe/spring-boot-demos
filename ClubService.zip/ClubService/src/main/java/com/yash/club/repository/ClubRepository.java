package com.yash.club.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.club.entity.Club;

@Repository
public interface ClubRepository extends JpaRepository<Club, Long> {

	List<Club> findByPlayerId(int playerId);

}
