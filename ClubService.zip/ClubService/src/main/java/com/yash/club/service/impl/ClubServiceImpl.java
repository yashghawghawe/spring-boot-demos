package com.yash.club.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.club.dto.ClubRequest;
import com.yash.club.dto.ClubResponse;
import com.yash.club.entity.Club;
import com.yash.club.repository.ClubRepository;
import com.yash.club.service.ClubService;

@Service
@Transactional
public class ClubServiceImpl implements ClubService {
	
	@Autowired
	private ClubRepository clubRepository;

	@Override
	public ClubResponse saveClub(ClubRequest clubRequest) {
		Club club = new Club();
		BeanUtils.copyProperties(clubRequest, club);
		Club savedClub = clubRepository.save(club);
		ClubResponse clubResponse = new ClubResponse();
		BeanUtils.copyProperties(savedClub, clubResponse);
		return clubResponse;
	}

	@Override
	public List<ClubResponse> getClubsByPlayerId(int playerId) {
		List<ClubResponse> clubResponses = getClubs(playerId);
		return clubResponses;
	}

	@Override
	public List<ClubResponse> getClubsByPlayerIdAsRequestParam(int playerId) {
		List<ClubResponse> clubResponses = getClubs(playerId);
		return clubResponses;
	}

	private List<ClubResponse> getClubs(int playerId) {
		List<Club> clubs = clubRepository.findByPlayerId(playerId);
		List<ClubResponse> clubResponses = new ArrayList<>();
		for (Club club : clubs) {
			ClubResponse response = new ClubResponse();
			BeanUtils.copyProperties(club, response);
			clubResponses.add(response);
		}
		return clubResponses;
	}

	@Override
	public List<ClubResponse> postClubByPlayerId(ClubRequest clubRequest) {
		Club club = new Club();
		BeanUtils.copyProperties(clubRequest, club);
		clubRepository.save(club);
		List<ClubResponse> clubResponses = getClubs(clubRequest.getPlayerId());
		return clubResponses;
	}

}
