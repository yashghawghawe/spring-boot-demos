package com.lambda;

import java.util.LinkedHashMap;
import java.util.Map;

public class LambdaExample {
    
    public static void main(String[] args) {
        Map<String, Integer> players =  new LinkedHashMap<>();
        players.put("Bruno", 25);
        players.put("Nemanja", 32);
        players.put("Paul", 27);
        players.put("Donny", 23);
        players.forEach((k,v) -> System.out.println("Name : " + k +" , age : "+ v));
    }

}
