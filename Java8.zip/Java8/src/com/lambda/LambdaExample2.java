package com.lambda;

@FunctionalInterface
interface Karable{
    int sum(int a,int b);
}
public class LambdaExample2 {
    
    public static void main(String[] args) {
        Karable s = (a,b) -> a+b;
        System.out.println(s.sum(5, 6));
        
        myLamba lamba = () -> System.out.println("Hi i am lambda -> expression");
        lamba.perform();
    }

}

interface myLamba{
	void perform();
}
