package com.functionalInterface;

import java.util.function.Function;

public class FunctionExample {

    public static void main(String[] args) {
        Function<Integer, String> fn = i -> i % 2 == 0 ? "1" : "0";
        System.out.println(fn.apply(15));
    }

}
