package com.functionalInterface;

import java.util.function.Predicate;

public class PredicateExample {
    
    public static void main(String[] args) {
        Predicate<Integer> greaterThan = i -> i > 10 ;
        Predicate<Integer> lowerThan = i -> i< 20;
        boolean result = greaterThan.and(lowerThan).test(18);
        System.out.println(result);
    }
}
