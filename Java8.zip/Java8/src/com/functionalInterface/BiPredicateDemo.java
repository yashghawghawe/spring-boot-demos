package com.functionalInterface;

import java.util.function.BiPredicate;

public class BiPredicateDemo {

    public static void main(String[] args) {
        BiPredicate<Integer, String> condition = (i,s) -> i > 20 && s.startsWith("S"); 
        System.out.println(condition.test(10, "Rama"));
        System.out.println(condition.test(30, "Shyam"));
        System.out.println(condition.test(30, "Ram"));
    }

}
