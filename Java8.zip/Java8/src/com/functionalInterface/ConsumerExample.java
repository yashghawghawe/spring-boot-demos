package com.functionalInterface;

public class ConsumerExample {
    public static void main(String[] args) {
        
    }
}
