package com.Date;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class DateExample2 {

    public static void main(String[] args) {
        //date
        LocalDate date = LocalDate.now();
        System.out.println(date);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy",Locale.US);
        System.out.println(formatter.format(date));
        //time
        LocalTime time = LocalTime.now();
        System.out.println(time);
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("HH:mm");
        System.out.println(dtf.format(time));
        System.out.println();
        //DateandTime
        LocalDateTime currdatetime=LocalDateTime.now();
        System.out.println(currdatetime);
        DateTimeFormatter dtf2=DateTimeFormatter.ofPattern("HH:mm");
        System.out.println(dtf2.format(currdatetime));
    }
}
