package com.Date;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class ChronoUnitExample {
    public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        LocalDate nextDay = today.plus(Period.ZERO);
        System.out.println(nextDay);
        LocalDate nextYear = today.plus(7, ChronoUnit.DAYS);
        System.out.println(nextYear);
    }
}
