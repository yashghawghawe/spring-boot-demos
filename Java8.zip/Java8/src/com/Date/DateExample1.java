package com.Date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateExample1 {
    public static void main(String[] args) {
        Date today = new Date();
        System.out.println(today);
        SimpleDateFormat sf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            sf.setLenient(true);
            Date d = sf.parse("30/02/2020");
            System.out.println(d);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
