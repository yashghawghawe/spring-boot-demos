package com.Optional;

import java.util.Optional;

public class Optional1 {
    //ofNUllable allows to pass null value
    public static void main(String[] args) {
        String words[] = new String[10];
        words[5] = "JAVA8";
        Optional<String> checknull = Optional.ofNullable(words[5]);
        if (checknull.isPresent()) {
            String lowerCase = words[5].toLowerCase();
            System.out.println(lowerCase);
        }
        System.out.println(checknull);
     }

}
