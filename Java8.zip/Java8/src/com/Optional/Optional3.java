package com.Optional;

import java.util.Optional;

public class Optional3 {
    
    public static void main(String[] args) {
        String words[] = new String[10];
        //words[3] = "JAVA8";
        try {
            System.out.println(Optional.of(words[3]).orElse("Null Value"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println();
        System.out.println(Optional.ofNullable(words[3]).orElse("NullValue"));
    }

}
