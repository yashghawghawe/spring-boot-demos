package com.Optional;

import java.util.Optional;

public class Optional2 {
    //of() throws null pointer exception if value is null
    public static void main(String[] args) {
        String words[] = new String[10];
        words[5] ="MAN UTD";
        Optional checknull = Optional.of(words[5]);
        if (checknull.isPresent()) {
            String lowercase = words[5].toLowerCase();
            System.out.println(lowercase);
        }
        System.out.println(checknull);
    }

}
