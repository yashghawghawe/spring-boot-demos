package com.Interface;

interface Showable {
    void square(int a);

    default void show() {
        System.out.println("Parent Claas Method");
    }
}

interface Showable2 {
    void square(int a);

    default void show() {
        System.out.println("Parent Claas Method");
    }
}

public class JavaInterface implements Showable {

    public static void main(String[] args) {
        JavaInterface interface1 = new JavaInterface();
        interface1.show();
        interface1.square(5);
    }

    @Override
    public void square(int a) {
        System.out.println(a * a);
    }

    public void show() {
        System.out.println("child Claas Method");
    }
}
