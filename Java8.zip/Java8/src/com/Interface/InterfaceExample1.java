package com.Interface;

interface TestInterface1 {
    // abstract method 
    public void square(int a);

    // public void square1 (int a); 
    default void display() {
        System.out.println("Default Method Executed");
    }

    // static method 
    static void show() {
        System.out.println("Static Method Executed");
    }
}

class InterfaceExample1 implements TestInterface1 {
    // Implementation of square abstract method 
    public void square(int a) {
        System.out.println(a * a);
    }

    public void display() {
        System.out.println("Display Method Executed");
    }

    public static void main(String args[]) {
        TestInterface1 d = new InterfaceExample1();
        d.square(4);
        d.display();
        //d.show();
    }
}
