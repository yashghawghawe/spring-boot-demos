package com.Interface;

interface doebale{
    default void doit(){
        System.out.println("do it");
    }
}
@FunctionalInterface// a functional interface extending a non functional interface
//a fuctional interface can extend only that interface that does not have any abstract method
interface Display extends doebale{
    void square(int a);
    
    default void message(){
    	System.out.println("hi");
    }
}

public class FunctionalInterfaceDemo implements Display {

    @Override
    public void square(int a) {
        System.out.println(a * a);

    }

    public static void main(String[] args) {
        FunctionalInterfaceDemo demo = new FunctionalInterfaceDemo();
        demo.square(5);
        demo.doit();
    }

}
