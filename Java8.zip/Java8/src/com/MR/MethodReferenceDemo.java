package com.MR;

import java.util.ArrayList;
import java.util.List;

public class MethodReferenceDemo {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        names.add("Yash");
        names.add("Bruno");
        names.add("Donny");
        names.stream().filter(n -> n.length() > 4).map(String::toUpperCase).forEach(System.out::println);
        System.out.println();
        names.forEach(System.out::println);
    }

}
