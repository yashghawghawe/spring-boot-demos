package com.MR;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;

class Person {
    private final String name;

    public Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

public class MethodReferenceExample3 {

    public static void main(String[] args) {
        Person person = new Person("Yash");
        Function<Person, String> getNameLambda = p -> p.getName();
        System.out.println(getNameLambda.apply(person));
        Function<Person, String> getNameMR = Person::getName;
        System.out.println(getNameMR.apply(person));
        System.out.println();
        Stream.of(new Person("Yash"), new Person("Rahul"), new Person("kartik")).map(p -> p.getName())
                .forEach(System.out::println);
        System.out.println();
        Stream.of(new Person("Yash"), new Person("Rahul"), new Person("kartik")).map(Person::getName)
                .forEach(System.out::println);

        List<Person> users = new ArrayList<>();
        Consumer<Person> byLambda = p -> users.add(person);
        Consumer<Person> byMR = users::add;

        Stream.of(new Person("Mike"), new Person("Maya"), new Person("Carl"))
                .forEach(persons -> users.add(person));

        Stream.of(new Person("Mike"), new Person("Maya"), new Person("Carl"))
                .forEach(users::add);
    }
}
