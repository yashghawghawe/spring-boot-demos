package com.MR;

import java.util.Arrays;

public class MethodReferenceExample2 {

    public static void main(String[] args) {
        String names[]= {"Paul","Bruno","Donny","Marcus","Anothny","Mason","Nemanja"};
        Arrays.sort(names, String::compareToIgnoreCase);
        for (String string : names) {
            System.out.println(string);
        }
    }

}
