package com.MR;

@FunctionalInterface
interface Messageable{  
   int display(String msg);  
  
}  
  public class MethodReferenceExample {  
      int demo(String str)
      {
          return str.length();
      }
    public static void main(String[] args) {  
        MethodReferenceExample m=new MethodReferenceExample();
        Messageable m1=m::demo;
        System.out.println(m1.display("Hey man"));
    }  
}  
