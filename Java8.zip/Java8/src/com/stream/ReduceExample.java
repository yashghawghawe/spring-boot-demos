package com.stream;

import java.util.Arrays;

public class ReduceExample {
    
    public static void main(String[] args) {
        //reduce() - to reduce a list or array into a single equivalent like sum
        int []numbers = {1,2,3,4,5,6,7,8,9,10};
        int sum = Arrays.stream(numbers).reduce(0, (a,b) -> a+b);
        System.out.println(sum);
    }

}
