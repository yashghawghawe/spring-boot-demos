package com.stream;

public class StreamExample {
    
    public static void main(String[] args) {
        String s = "Manchester United";
        s.chars().parallel().forEach(str -> System.out.print((char)str) );
        System.out.println();
        s.chars().parallel().forEachOrdered(str -> System.out.print((char)str) );
    }
}
