package com.stream;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public class Stream3 {

    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(6, 6, 1, 2, 2, 8, 9);
        Stream<Integer> result =list.stream().sorted(Collections.reverseOrder());
        result.forEach(n -> System.out.println(n));
    }

}
