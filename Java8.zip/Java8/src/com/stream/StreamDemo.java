package com.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamDemo {

    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(6,6,1,2,2,8,9);
        Stream<Integer> distinct = list.stream().distinct();
        System.out.println(distinct.count());
        System.out.println();
        List<String> names = 
                Arrays.asList("Reflection","Collection","Stream"); 
        List<String> result4 = names.stream().filter(s -> s.startsWith("C")).collect(Collectors.toList());
        System.out.println(result4);
        List<Integer> result = list.stream().filter(n -> n.intValue() > 4).map(n -> n).
                collect(Collectors.toList());
        System.out.println(result);
        List<Integer> result2 = list.stream().sorted().collect(Collectors.toList());
        System.out.println(result2);
        System.out.println();
        result.forEach(num -> System.out.println(num));
        System.out.println();
        List<Integer> result3 = list.stream().map(x -> x*x).collect(Collectors.toList());
        System.out.println(result3);
    }
}
