package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

class Product_Stream4 {
    int id;
    String name;
    float price;

    public Product_Stream4(int id, String name, float price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product_Stream4 [id=" + id + ", name=" + name + ", price=" + price + "]";
    }

}

public class StreamExample2 {
    public static void main(String[] args) {
        List<Product_Stream4> productsList = new ArrayList<Product_Stream4>();
        //Adding Products  
        productsList.add(new Product_Stream4(1, "HP Laptop", 32000f));
        productsList.add(new Product_Stream4(2, "Dell Laptop", 30000f));
        productsList.add(new Product_Stream4(3, "Lenevo Laptop", 28000f));
        productsList.add(new Product_Stream4(4, "Sony Laptop", 28000f));
        productsList.add(new Product_Stream4(5, "Apple Laptop", 90000f));
        // Using Collectors's method to sum the prices.  
        double total = productsList.stream().collect(Collectors.averagingDouble(p -> p.price));
        System.out.println(total);
        System.out.println();
        productsList.stream().filter(p -> p.price > 25000).map(p -> p.price).forEach(p -> System.out.print(p + " "));
        System.out.println();
        System.out.println();
        Set<Float> set = productsList.stream().filter(p -> p.price > 25000).map(p -> p.price)
                .collect(Collectors.toSet());
        set.forEach(s -> System.out.println(s));
    }
}
