package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Products {
    int id;
    String name;
    float price;

    public Products(int id, String name, float price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Products [id=" + id + ", name=" + name + ", price=" + price + "]";
    }
}

public class Stream2 {
    public static void main(String[] args) {
        List<Products> products = new ArrayList<Products>();
        products.add(new Products(1, "Redmi Phone", 13000));
        products.add(new Products(2, "Samsung Phone", 15000));
        products.add(new Products(3, "Oneplus Phone", 30000));
        products.add(new Products(4, "Apple Phone", 25000));

        products.forEach(p -> System.out.println(p.name + " - " + p.price));
        System.out.println();
        products.forEach(p -> System.out.println(p));
        System.out.println();
        List<String> product = products.stream().filter(p -> p.price >= 15000).map(p -> p.name)
                .collect(Collectors.toList());
        product.forEach(p -> System.out.println(p));
        System.out.println();
        boolean match = products.stream().filter(p -> p.price >= 13000).mapToInt(p -> (int) p.price)
                .anyMatch(p -> p == 13000);
        System.out.println(match);
        int max = products.stream().filter(p -> p.price >= 13000).mapToInt(p -> (int) p.price).max().orElse(0);
        System.out.println(max);
        int average = (int) products.stream().filter(p -> p.price >= 13000).mapToInt(p -> (int) p.price).average()
                .orElse(0);
        System.out.println(average);
        int count = (int) products.stream().filter(p -> p.price >= 13000).mapToInt(p -> (int) p.price).count();
        System.out.println(count);
        System.out.println();
        List<Float> prices = new ArrayList<>();
        for (Products price : products) {
            if (price.price > 11000) {
                prices.add(price.price);
            }
        }
        prices.forEach(System.out::println);
    }
}
