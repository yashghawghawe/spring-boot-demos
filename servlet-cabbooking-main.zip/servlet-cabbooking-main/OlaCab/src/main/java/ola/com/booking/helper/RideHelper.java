package ola.com.booking.helper;

public class RideHelper {

	static int count = 1;

	public static int getIncrement() {
		return count++;
	}

}
