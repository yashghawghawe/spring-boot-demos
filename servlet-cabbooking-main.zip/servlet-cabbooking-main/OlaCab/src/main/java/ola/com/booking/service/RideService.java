package ola.com.booking.service;

import ola.com.booking.model.Ride;

public interface RideService {
	
	public void BookRide(Ride ride);

	public Object getRide();

}

